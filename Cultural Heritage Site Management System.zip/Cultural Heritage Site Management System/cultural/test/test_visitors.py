import unittest
from datetime import datetime
from core.models.visitors import VisitorGroup, ReservationPriority
import os
import sys 

# 动态获取项目根目录
current_file = os.path.abspath(__file__)
current_dir = os.path.dirname(current_file)
project_root = os.path.dirname(current_dir)
sys.path.insert(0, project_root)

class TestVisitorGroup(unittest.TestCase):
    """游客组的单元测试"""
    
    def setUp(self):
        """测试前的准备工作"""
        self.visitor1 = VisitorGroup(
            group_id=1,
            count=10,
            arrival_time="09:00",
            reservation_priority=ReservationPriority.HIGH
        )
        
        self.visitor2 = VisitorGroup(
            group_id=2,
            count=8,
            arrival_time="10:30",
            reservation_priority=ReservationPriority.MEDIUM
        )
        
        self.visitor3 = VisitorGroup(
            group_id=3,
            count=5,
            arrival_time="11:00",
            reservation_priority=ReservationPriority.LOW
        )
        
        self.visitor_with_preference = VisitorGroup(
            group_id=4,
            count=12,
            arrival_time="14:00",
            reservation_priority=ReservationPriority.HIGH,
            preferred_era="Ancient"
        )
    
    def test_visitor_creation(self):
        """测试游客组对象创建"""
        self.assertEqual(self.visitor1.group_id, 1)
        self.assertEqual(self.visitor1.arrival_time, "09:00")
        self.assertEqual(self.visitor1.reservation_priority, ReservationPriority.HIGH)
        self.assertIsNone(self.visitor1.preferred_era)
    
    def test_visitor_with_preference(self):
        """测试带偏好的游客组创建"""
        self.assertEqual(self.visitor_with_preference.group_id, 4)
        self.assertEqual(self.visitor_with_preference.arrival_time, "14:00")
        self.assertEqual(self.visitor_with_preference.reservation_priority, ReservationPriority.HIGH)
        self.assertEqual(self.visitor_with_preference.preferred_era, "Ancient")
    
    def test_visitor_repr(self):
        """测试游客组的字符串表示"""
        # 无偏好的游客组
        expected1 = "VisitorGroup(id=1, count=10, arrival_time='09:00', priority=HIGH)"
        self.assertEqual(repr(self.visitor1), expected1)
        
        # 有偏好的游客组
        expected2 = "VisitorGroup(id=4, count=12, arrival_time='14:00', priority=HIGH, preferred_era='Ancient')"
        self.assertEqual(repr(self.visitor_with_preference), expected2)
    
    def test_visitor_equality(self):
        """测试游客组相等性比较"""
        # 相同ID的游客组应该相等
        visitor_copy = VisitorGroup(
            group_id=1,
            count=10,
            arrival_time="15:00",
            reservation_priority=ReservationPriority.LOW,
            preferred_era="Modern"
        )
        self.assertEqual(self.visitor1, visitor_copy)
        
        # 不同ID的游客组不应该相等
        self.assertNotEqual(self.visitor1, self.visitor2)
    
    def test_visitor_comparison(self):
        """测试游客组比较（用于优先队列排序）"""
        # 优先级顺序：HIGH < MEDIUM < LOW（数字越小优先级越高）
        self.assertLess(self.visitor1, self.visitor2)  # HIGH < MEDIUM
        self.assertLess(self.visitor2, self.visitor3)  # MEDIUM < LOW
        self.assertLess(self.visitor1, self.visitor3)  # HIGH < LOW
        # 相同优先级时按到达时间排序
        visitor_same_priority = VisitorGroup(
            group_id=5,
            count=10,
            arrival_time="08:00",  # 更早的时间
            reservation_priority=ReservationPriority.HIGH
        )
        self.assertLess(visitor_same_priority, self.visitor1)  # 08:00 < 09:00
    
    def test_visitor_hash(self):
        """测试游客组哈希值"""
        visitor_copy = VisitorGroup(
            group_id=1,
            count=10,
            arrival_time="15:00",
            reservation_priority=ReservationPriority.LOW
        )
        self.assertEqual(hash(self.visitor1), hash(visitor_copy))
        self.assertNotEqual(hash(self.visitor1), hash(self.visitor2))
    
    def test_parse_time(self):
        """测试时间解析"""
        # 正常时间格式
        time_obj = self.visitor1._parse_time("09:00")
        self.assertEqual(time_obj.hour, 9)
        self.assertEqual(time_obj.minute, 0)
        
        # 无效时间格式应该返回默认时间
        default_time = self.visitor1._parse_time("invalid")
        self.assertEqual(default_time.hour, 0)
        self.assertEqual(default_time.minute, 0)
    
    def test_get_priority_score(self):
        """测试获取优先级分数"""
        self.assertEqual(self.visitor1.get_priority_score(), 3)  # HIGH
        self.assertEqual(self.visitor2.get_priority_score(), 2)  # MEDIUM
        self.assertEqual(self.visitor3.get_priority_score(), 1)  # LOW
    
    def test_visitor_to_dict(self):
        """测试游客组转换为字典"""
        expected_dict = {
            'group_id': 1,
            'count': 10,
            'arrival_time': '09:00',
            'reservation_priority': 'HIGH',
            'preferred_era': None
        }
        self.assertEqual(self.visitor1.to_dict(), expected_dict)
        
        # 有偏好的游客组
        expected_dict_with_preference = {
            'group_id': 4,
            'count': 12,
            'arrival_time': '14:00',
            'reservation_priority': 'HIGH',
            'preferred_era': 'Ancient'
        }
        self.assertEqual(self.visitor_with_preference.to_dict(), expected_dict_with_preference)
    
    def test_visitor_from_dict(self):
        """测试从字典创建游客组"""
        data = {
            'group_id': 6,
            'count': 15,
            'arrival_time': '16:30',
            'reservation_priority': 'MEDIUM',
            'preferred_era': 'Renaissance'
        }
        visitor = VisitorGroup.from_dict(data)
        self.assertEqual(visitor.group_id, 6)
        self.assertEqual(visitor.count, 15)
        self.assertEqual(visitor.arrival_time, '16:30')
        self.assertEqual(visitor.reservation_priority, ReservationPriority.MEDIUM)
        self.assertEqual(visitor.preferred_era, 'Renaissance')
    
    def test_reservation_priority_enum(self):
        """测试预约优先级枚举"""
        self.assertEqual(ReservationPriority.HIGH.value, "HIGH")
        self.assertEqual(ReservationPriority.MEDIUM.value, "MEDIUM")
        self.assertEqual(ReservationPriority.LOW.value, "LOW")


if __name__ == '__main__':
    unittest.main()