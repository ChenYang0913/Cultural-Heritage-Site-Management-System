import unittest
from datetime import datetime
from core.structures.tour_queue import TourQueue, load_from_csv
from core.models.visitors import VisitorGroup, ReservationPriority

class TestTourQueue(unittest.TestCase):
    def setUp(self):
        """初始化测试数据"""
        self.queue = TourQueue()
        self.group1 = VisitorGroup(1, 10, "10:00", ReservationPriority.HIGH)
        self.group2 = VisitorGroup(2, 8, "09:30", ReservationPriority.MEDIUM)
        self.group3 = VisitorGroup(3, 5, "10:30", ReservationPriority.HIGH)

    def test_add_group(self):
        """测试添加游客组并验证排序"""
        self.queue.add_visitor_group(self.group3)  # HIGH, 10:30
        self.queue.add_visitor_group(self.group1)  # HIGH, 10:00
        self.queue.add_visitor_group(self.group2)  # MEDIUM, 9:30
        all_groups = self.queue.get_all_visitor_groups()
        # 期望顺序：group1(HIGH,10:00), group3(HIGH,10:30), group2(MEDIUM,9:30)
        self.assertEqual(all_groups[0], self.group1)
        self.assertEqual(all_groups[1], self.group3)
        self.assertEqual(all_groups[2], self.group2)

    def test_remove_group(self):
        """测试移除游客组"""
        self.queue.add_visitor_group(self.group1)
        self.queue.add_visitor_group(self.group2)
        self.queue.add_visitor_group(self.group3)
        # 先移除group1
        removed = self.queue.remove_visitor_group(1)
        self.assertEqual(removed, self.group1)
        # 再移除group3
        removed = self.queue.remove_visitor_group(3)
        self.assertEqual(removed, self.group3)
        # 再移除group2
        removed = self.queue.remove_visitor_group(2)
        self.assertEqual(removed, self.group2)
        # 队列应为空
        self.assertEqual(len(self.queue), 0)

    def test_peek_next_group(self):
        """测试查看下一个游客组"""
        self.queue.add_visitor_group(self.group2)  # MEDIUM 9:30
        self.queue.add_visitor_group(self.group1)  # HIGH 10:00
        
        # 优先级高的 group1 应该在队首
        self.assertEqual(self.queue.get_next_visitor_group(), self.group1)

    def test_reschedule_group(self):
        """测试重新安排游客组时间"""
        self.queue.add_visitor_group(self.group1)  # G001 10:00 HIGH
        self.queue.add_visitor_group(self.group3)  # G003 10:30 HIGH
        
        # 调整 G001 的时间为更早
        new_time = "09:00"
        self.assertTrue(self.queue.reschedule_visitor_group(1, new_time))
        
        # 新队列顺序：G001（9:00 HIGH）→ G003（10:30 HIGH）
        all_groups = self.queue.get_all_visitor_groups()
        expected_group = VisitorGroup(1, 10, new_time, ReservationPriority.HIGH)
        self.assertEqual(all_groups[0], expected_group)
        self.assertEqual(all_groups[1], self.group3)

    def test_load_from_csv(self):
        """测试从 CSV 文件加载数据"""
        # 注意：需要在测试目录下创建一个示例 CSV 文件
        # 或使用临时文件（此处简化处理）
        try:
            queue = load_from_csv("test_data.csv")
            self.assertIsInstance(queue, TourQueue)
            # 可进一步验证 CSV 加载的数据（根据实际文件内容）
        except FileNotFoundError:
            # 测试环境可能没有该文件，跳过此测试
            self.skipTest("测试 CSV 文件不存在，跳过此测试")

    def test_queue_initialization(self):
        """测试队列初始化"""
        self.assertEqual(len(self.queue), 0)
        self.assertTrue(self.queue.is_empty())
    
    def test_add_visitor_group(self):
        """测试添加游客组"""
        # 添加游客组
        result = self.queue.add_visitor_group(self.group1)
        self.assertTrue(result)
        self.assertEqual(len(self.queue), 1)
        self.assertFalse(self.queue.is_empty())
        
        # 添加相同ID的游客组应该失败
        duplicate_group = VisitorGroup(1, 10, "10:00", ReservationPriority.HIGH)
        result = self.queue.add_visitor_group(duplicate_group)
        self.assertFalse(result)
        self.assertEqual(len(self.queue), 1)  # 数量不变
    
    def test_remove_visitor_group(self):
        """测试移除游客组"""
        # 添加游客组
        self.queue.add_visitor_group(self.group1)
        self.assertEqual(len(self.queue), 1)
        
        # 移除存在的游客组
        removed = self.queue.remove_visitor_group(1)
        self.assertEqual(removed, self.group1)
        self.assertEqual(len(self.queue), 0)
        self.assertTrue(self.queue.is_empty())
        
        # 移除不存在的游客组
        removed = self.queue.remove_visitor_group(3)
        self.assertIsNone(removed)
    
    def test_get_next_visitor_group(self):
        """测试查看下一个游客组（不移除）"""
        # 空队列
        next_group = self.queue.get_next_visitor_group()
        self.assertIsNone(next_group)
        
        # 添加游客组
        self.queue.add_visitor_group(self.group1)
        next_group = self.queue.get_next_visitor_group()
        self.assertEqual(next_group, self.group1)
        self.assertEqual(len(self.queue), 1)  # 数量不变
    
    def test_dequeue_next_visitor_group(self):
        """测试移除并返回下一个游客组"""
        # 空队列
        next_group = self.queue.dequeue_next_visitor_group()
        self.assertIsNone(next_group)
        
        # 添加游客组
        self.queue.add_visitor_group(self.group1)
        next_group = self.queue.dequeue_next_visitor_group()
        self.assertEqual(next_group, self.group1)
        self.assertEqual(len(self.queue), 0)
        self.assertTrue(self.queue.is_empty())
    
    def test_priority_queue_ordering(self):
        """测试优先队列排序"""
        self.queue.add_visitor_group(self.group3)  # HIGH, 10:30
        self.queue.add_visitor_group(self.group1)  # HIGH, 10:00
        self.queue.add_visitor_group(self.group2)  # MEDIUM, 9:30
        next_group = self.queue.get_next_visitor_group()
        self.assertEqual(next_group, self.group1)  # HIGH, 10:00 first
        self.queue.dequeue_next_visitor_group()
        next_group = self.queue.get_next_visitor_group()
        self.assertEqual(next_group, self.group3)  # HIGH, 10:30 second
        self.queue.dequeue_next_visitor_group()
        next_group = self.queue.get_next_visitor_group()
        self.assertEqual(next_group, self.group2)  # MEDIUM, 9:30 last
    
    def test_same_priority_time_ordering(self):
        """测试相同优先级时按时间排序"""
        # 两个HIGH优先级，不同时间
        groupA = VisitorGroup(4, 10, "08:00", ReservationPriority.HIGH)
        groupB = VisitorGroup(5, 10, "09:00", ReservationPriority.HIGH)
        self.queue.add_visitor_group(groupB)
        self.queue.add_visitor_group(groupA)
        all_groups = self.queue.get_all_visitor_groups()
        self.assertEqual(all_groups[0], groupA)  # 08:00 first
        self.assertEqual(all_groups[1], groupB)  # 09:00 second
    
    def test_reschedule_visitor_group(self):
        """测试重新安排游客组时间"""
        # 添加游客组
        self.queue.add_visitor_group(self.group1)
        self.assertEqual(len(self.queue), 1)
        
        # 重新安排时间
        result = self.queue.reschedule_visitor_group(1, "15:00")
        self.assertTrue(result)
        
        # 验证时间已更新
        updated_group = self.queue.get_visitor_group(1)
        self.assertEqual(updated_group.arrival_time, "15:00")
        self.assertEqual(updated_group.reservation_priority, ReservationPriority.HIGH)  # 优先级不变
        
        # 重新安排不存在的游客组
        result = self.queue.reschedule_visitor_group(3, "16:00")
        self.assertFalse(result)
    
    def test_update_visitor_group_priority(self):
        """测试更新游客组优先级"""
        # 添加游客组
        self.queue.add_visitor_group(self.group1)
        
        # 更新优先级
        result = self.queue.update_visitor_group_priority(1, ReservationPriority.LOW)
        self.assertTrue(result)
        
        # 验证优先级已更新
        updated_group = self.queue.get_visitor_group(1)
        self.assertEqual(updated_group.reservation_priority, ReservationPriority.LOW)
        self.assertEqual(updated_group.arrival_time, "10:00")  # 时间不变
        
        # 更新不存在的游客组
        result = self.queue.update_visitor_group_priority(3, ReservationPriority.HIGH)
        self.assertFalse(result)
    
    def test_get_visitor_group(self):
        """测试获取指定ID的游客组"""
        # 添加游客组
        self.queue.add_visitor_group(self.group1)
        
        # 获取存在的游客组
        found = self.queue.get_visitor_group(1)
        self.assertEqual(found, self.group1)
        
        # 获取不存在的游客组
        not_found = self.queue.get_visitor_group(3)
        self.assertIsNone(not_found)
    
    def test_get_all_visitor_groups(self):
        """测试获取所有游客组"""
        self.queue.add_visitor_group(self.group1)
        self.queue.add_visitor_group(self.group2)
        self.queue.add_visitor_group(self.group3)
        all_groups = self.queue.get_all_visitor_groups()
        # 期望顺序：group1(HIGH,10:00), group3(HIGH,10:30), group2(MEDIUM,9:30)
        self.assertEqual(all_groups[0], self.group1)
        self.assertEqual(all_groups[1], self.group3)
        self.assertEqual(all_groups[2], self.group2)
    
    def test_get_queue_position(self):
        """测试获取游客组在队列中的位置"""
        self.queue.add_visitor_group(self.group3)  # HIGH, 10:30
        self.queue.add_visitor_group(self.group1)  # HIGH, 10:00
        self.queue.add_visitor_group(self.group2)  # MEDIUM, 9:30
        # 期望顺序：group1(1), group3(2), group2(3)
        position1 = self.queue.get_queue_position(1)
        self.assertEqual(position1, 1)
        position2 = self.queue.get_queue_position(3)
        self.assertEqual(position2, 2)
        position3 = self.queue.get_queue_position(2)
        self.assertEqual(position3, 3)
    
    def test_get_queue_statistics(self):
        """测试获取队列统计信息"""
        # 添加带偏好的游客组
        group_with_preference = VisitorGroup(5, 10, "14:00", ReservationPriority.HIGH, "Ancient")
        
        self.queue.add_visitor_group(self.group1)  # HIGH
        self.queue.add_visitor_group(self.group2)  # MEDIUM
        self.queue.add_visitor_group(group_with_preference)  # HIGH with preference
        
        stats = self.queue.get_queue_statistics()
        
        self.assertEqual(stats['total_groups'], 3)
        self.assertEqual(stats['significance_distribution']['HIGH'], 2)
        self.assertEqual(stats['significance_distribution']['MEDIUM'], 1)
        self.assertEqual(stats['significance_distribution']['LOW'], 0)
    
    def test_clear_queue(self):
        """测试清空队列"""
        # 添加游客组
        self.queue.add_visitor_group(self.group1)
        self.queue.add_visitor_group(self.group2)
        self.assertEqual(len(self.queue), 2)
        
        # 清空队列
        self.queue.clear_queue()
        self.assertEqual(len(self.queue), 0)
        self.assertTrue(self.queue.is_empty())
    
    def test_queue_to_dict(self):
        """测试队列转换为字典"""
        # 添加游客组
        self.queue.add_visitor_group(self.group1)
        self.queue.add_visitor_group(self.group2)
        
        queue_dict = self.queue.to_dict()
        
        self.assertEqual(queue_dict['total_groups'], 2)
        self.assertEqual(len(queue_dict['groups']), 2)
        self.assertIn('statistics', queue_dict)
        
        # 验证组数据
        group_ids = [group['group_id'] for group in queue_dict['groups']]
        self.assertIn(1, group_ids)
        self.assertIn(2, group_ids)
    
    def test_queue_repr(self):
        """测试队列的字符串表示"""
        self.queue.add_visitor_group(self.group1)
        expected = "TourQueue(total_groups=1)"
        self.assertEqual(repr(self.queue), expected)

if __name__ == '__main__':
    unittest.main()