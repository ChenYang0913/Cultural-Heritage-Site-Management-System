import unittest
from core.models.artifact import Artifact, Significance, ArtifactType


class TestArtifact(unittest.TestCase):
    """文物类的单元测试"""
    
    def setUp(self):
        """测试前的准备工作"""
        self.artifact1 = Artifact(
            artifact_id=1,
            name="Test Artifact 1",
            era="Ancient",
            significance=Significance.HIGH,
            artifact_type=ArtifactType.SCULPTURE
        )
        
        self.artifact2 = Artifact(
            artifact_id=2,
            name="Test Artifact 2",
            era="Medieval",
            significance=Significance.MEDIUM,
            artifact_type=ArtifactType.PAINTING
        )
        
        self.artifact3 = Artifact(
            artifact_id=3,
            name="Test Artifact 3",
            era="Modern",
            significance=Significance.LOW,
            artifact_type=ArtifactType.DOCUMENT
        )
    
    def test_artifact_creation(self):
        """测试文物对象创建"""
        self.assertEqual(self.artifact1.artifact_id, 1)
        self.assertEqual(self.artifact1.name, "Test Artifact 1")
        self.assertEqual(self.artifact1.era, "Ancient")
        self.assertEqual(self.artifact1.significance, Significance.HIGH)
        self.assertEqual(self.artifact1.artifact_type, ArtifactType.SCULPTURE)
    
    def test_artifact_repr(self):
        """测试文物的字符串表示"""
        expected = "Artifact(id=1, name='Test Artifact 1', era='Ancient', significance=HIGH, type=SCULPTURE)"
        self.assertEqual(repr(self.artifact1), expected)
    
    def test_artifact_equality(self):
        """测试文物相等性比较"""
        # 相同ID的文物应该相等
        artifact_copy = Artifact(
            artifact_id=1,
            name="Different Name",
            era="Different Era",
            significance=Significance.LOW,
            artifact_type=ArtifactType.PAINTING
        )
        self.assertEqual(self.artifact1, artifact_copy)
        
        # 不同ID的文物不应该相等
        self.assertNotEqual(self.artifact1, self.artifact2)
    
    def test_artifact_comparison(self):
        """测试文物比较（按重要性排序）"""
        # HIGH > MEDIUM > LOW
        self.assertGreater(self.artifact1, self.artifact2)  # HIGH > MEDIUM
        self.assertGreater(self.artifact2, self.artifact3)  # MEDIUM > LOW
        self.assertGreater(self.artifact1, self.artifact3)  # HIGH > LOW
        
        # 相同重要性时按ID排序
        artifact_same_priority = Artifact(
            artifact_id=4,
            name="Test Artifact 4",
            era="Ancient",
            significance=Significance.HIGH,
            artifact_type=ArtifactType.SCULPTURE
        )
        self.assertLess(self.artifact1, artifact_same_priority)  # ID 1 < ID 4
    
    def test_artifact_hash(self):
        """测试文物哈希值"""
        artifact_copy = Artifact(
            artifact_id=1,
            name="Different Name",
            era="Different Era",
            significance=Significance.LOW,
            artifact_type=ArtifactType.PAINTING
        )
        self.assertEqual(hash(self.artifact1), hash(artifact_copy))
        self.assertNotEqual(hash(self.artifact1), hash(self.artifact2))
    
    def test_artifact_to_dict(self):
        """测试文物转换为字典"""
        expected_dict = {
            'artifact_id': 1,
            'name': 'Test Artifact 1',
            'era': 'Ancient',
            'type': 'SCULPTURE',
            'significance': 'HIGH',
            'description': ''
        }
        self.assertEqual(self.artifact1.to_dict(), expected_dict)
    
    def test_artifact_from_dict(self):
        """测试从字典创建文物"""
        data = {
            'artifact_id': 5,
            'name': 'Test Artifact 5',
            'era': 'Renaissance',
            'significance': 'MEDIUM',
            'type': 'PAINTING'
        }
        artifact = Artifact.from_dict(data)
        self.assertEqual(artifact.artifact_id, 5)
        self.assertEqual(artifact.name, 'Test Artifact 5')
        self.assertEqual(artifact.era, 'Renaissance')
        self.assertEqual(artifact.significance, Significance.MEDIUM)
        self.assertEqual(artifact.artifact_type, ArtifactType.PAINTING)
    
    def test_significance_enum(self):
        """测试重要性枚举"""
        self.assertEqual(Significance.HIGH.value, "HIGH")
        self.assertEqual(Significance.MEDIUM.value, "MEDIUM")
        self.assertEqual(Significance.LOW.value, "LOW")
    
    def test_artifact_type_enum(self):
        """测试文物类型枚举"""
        self.assertEqual(ArtifactType.SCULPTURE.value, "SCULPTURE")
        self.assertEqual(ArtifactType.PAINTING.value, "PAINTING")
        self.assertEqual(ArtifactType.DOCUMENT.value, "DOCUMENT")


if __name__ == '__main__':
    unittest.main()

