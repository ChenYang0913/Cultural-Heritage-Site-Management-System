# test/test_tree.py
import sys
import os
import unittest
from core.models.artifact import Artifact, ArtifactType, Significance
from core.structures.artifact_tree import ArtifactTree, ArtifactTreeNode

current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(current_dir)
sys.path.append(project_root)

class TestArtifactTree(unittest.TestCase):
    """文物树的单元测试"""
    
    def setUp(self):
        """测试前的准备工作"""
        self.tree = ArtifactTree()
        
        # 创建测试文物
        self.artifact1 = Artifact(
            artifact_id=1,
            name="Statue of Zeus",
            era="Ancient",
            significance=Significance.HIGH,
            artifact_type=ArtifactType.SCULPTURE
        )
        
        self.artifact2 = Artifact(
            artifact_id=2,
            name="Mona Lisa",
            era="Renaissance",
            significance=Significance.HIGH,
            artifact_type=ArtifactType.PAINTING
        )
        
        self.artifact3 = Artifact(
            artifact_id=3,
            name="Rosetta Stone",
            era="Ancient",
            significance=Significance.HIGH,
            artifact_type=ArtifactType.DOCUMENT
        )
        
        self.artifact4 = Artifact(
            artifact_id=4,
            name="The Scream",
            era="Modern",
            significance=Significance.MEDIUM,
            artifact_type=ArtifactType.PAINTING
        )
    
    def test_tree_initialization(self):
        """测试树初始化"""
        self.assertIsNotNone(self.tree.root)
        self.assertEqual(self.tree.root.key, "root")
        self.assertEqual(len(self.tree), 0)
    
    def test_add_artifact(self):
        """测试添加文物"""
        # 添加文物
        result = self.tree.add_artifact(self.artifact1)
        self.assertTrue(result)
        self.assertEqual(len(self.tree), 1)
        
        # 验证树结构
        era_node = self.tree.root.children.get("Ancient")
        self.assertIsNotNone(era_node)
        
        type_node = era_node.children.get("SCULPTURE")
        self.assertIsNotNone(type_node)
        
        significance_node = type_node.children.get("HIGH")
        self.assertIsNotNone(significance_node)
        self.assertEqual(len(significance_node.artifacts), 1)
        self.assertEqual(significance_node.artifacts[0], self.artifact1)
    
    def test_add_multiple_artifacts(self):
        """测试添加多个文物"""
        # 添加多个文物
        self.tree.add_artifact(self.artifact1)  # Ancient, SCULPTURE, HIGH
        self.tree.add_artifact(self.artifact2)  # Renaissance, PAINTING, HIGH
        self.tree.add_artifact(self.artifact3)  # Ancient, DOCUMENT, HIGH
        self.tree.add_artifact(self.artifact4)  # Modern, PAINTING, MEDIUM
        
        self.assertEqual(len(self.tree), 4)
        
        # 验证不同时代的文物
        ancient_artifacts = self.tree.get_artifacts_by_era("Ancient")
        self.assertEqual(len(ancient_artifacts), 2)
        
        renaissance_artifacts = self.tree.get_artifacts_by_era("Renaissance")
        self.assertEqual(len(renaissance_artifacts), 1)
        
        modern_artifacts = self.tree.get_artifacts_by_era("Modern")
        self.assertEqual(len(modern_artifacts), 1)
    
    def test_remove_artifact(self):
        """测试移除文物"""
        # 添加文物
        self.tree.add_artifact(self.artifact1)
        self.assertEqual(len(self.tree), 1)
        
        # 移除文物
        removed = self.tree.remove_artifact(1)
        self.assertEqual(removed, self.artifact1)
        self.assertEqual(len(self.tree), 0)
        
        # 验证树结构被清理
        self.assertEqual(len(self.tree.root.children), 0)
    
    def test_remove_nonexistent_artifact(self):
        """测试移除不存在的文物"""
        removed = self.tree.remove_artifact(999)
        self.assertIsNone(removed)
    
    def test_find_artifact(self):
        """测试查找文物"""
        self.tree.add_artifact(self.artifact1)
        
        # 查找存在的文物
        found = self.tree.find_artifact(1)
        self.assertEqual(found, self.artifact1)
        
        # 查找不存在的文物
        not_found = self.tree.find_artifact(999)
        self.assertIsNone(not_found)
    
    def test_search_artifacts_by_type(self):
        """测试按类型搜索文物"""
        self.tree.add_artifact(self.artifact1)  # SCULPTURE
        self.tree.add_artifact(self.artifact2)  # PAINTING
        self.tree.add_artifact(self.artifact3)  # DOCUMENT
        
        # 搜索雕塑
        sculptures = self.tree.search_artifacts(artifact_type=ArtifactType.SCULPTURE)
        self.assertEqual(len(sculptures), 1)
        self.assertEqual(sculptures[0], self.artifact1)
        
        # 搜索绘画
        paintings = self.tree.search_artifacts(artifact_type=ArtifactType.PAINTING)
        self.assertEqual(len(paintings), 1)
        self.assertEqual(paintings[0], self.artifact2)
    
    def test_search_artifacts_by_significance(self):
        """测试按重要性搜索文物"""
        self.tree.add_artifact(self.artifact1)  # HIGH
        self.tree.add_artifact(self.artifact2)  # HIGH
        self.tree.add_artifact(self.artifact4)  # MEDIUM
        
        # 搜索高重要性文物
        high_artifacts = self.tree.search_artifacts(significance=Significance.HIGH)
        self.assertEqual(len(high_artifacts), 2)
        
        # 搜索中等重要性文物
        medium_artifacts = self.tree.search_artifacts(significance=Significance.MEDIUM)
        self.assertEqual(len(medium_artifacts), 1)
        self.assertEqual(medium_artifacts[0], self.artifact4)
    
    def test_search_artifacts_by_type_and_significance(self):
        """测试按类型和重要性组合搜索"""
        self.tree.add_artifact(self.artifact1)  # SCULPTURE, HIGH
        self.tree.add_artifact(self.artifact2)  # PAINTING, HIGH
        self.tree.add_artifact(self.artifact4)  # PAINTING, MEDIUM
        
        # 搜索高重要性的绘画
        high_paintings = self.tree.search_artifacts(
            artifact_type=ArtifactType.PAINTING,
            significance=Significance.HIGH
        )
        self.assertEqual(len(high_paintings), 1)
        self.assertEqual(high_paintings[0], self.artifact2)
    
    def test_get_all_artifacts(self):
        """测试获取所有文物"""
        self.tree.add_artifact(self.artifact1)
        self.tree.add_artifact(self.artifact2)
        self.tree.add_artifact(self.artifact3)
        
        all_artifacts = self.tree.get_all_artifacts()
        self.assertEqual(len(all_artifacts), 3)
        self.assertIn(self.artifact1, all_artifacts)
        self.assertIn(self.artifact2, all_artifacts)
        self.assertIn(self.artifact3, all_artifacts)
    
    def test_get_statistics(self):
        """测试获取统计信息"""
        self.tree.add_artifact(self.artifact1)  # Ancient, SCULPTURE, HIGH
        self.tree.add_artifact(self.artifact2)  # Renaissance, PAINTING, HIGH
        self.tree.add_artifact(self.artifact3)  # Ancient, DOCUMENT, HIGH
        self.tree.add_artifact(self.artifact4)  # Modern, PAINTING, MEDIUM
        
        stats = self.tree.get_statistics()
        
        self.assertEqual(stats['total_artifacts'], 4)
        self.assertEqual(stats['eras']['Ancient'], 2)
        self.assertEqual(stats['eras']['Renaissance'], 1)
        self.assertEqual(stats['eras']['Modern'], 1)
        self.assertEqual(stats['types']['SCULPTURE'], 1)
        self.assertEqual(stats['types']['PAINTING'], 2)
        self.assertEqual(stats['types']['DOCUMENT'], 1)
        self.assertEqual(stats['significance']['HIGH'], 3)
        self.assertEqual(stats['significance']['MEDIUM'], 1)
    
    def test_tree_structure(self):
        """测试获取树结构"""
        self.tree.add_artifact(self.artifact1)
        
        structure = self.tree.get_tree_structure()
        self.assertEqual(structure['key'], 'root')
        self.assertIn('Ancient', structure['children'])
        
        ancient_node = structure['children']['Ancient']
        self.assertEqual(ancient_node['key'], 'Ancient')
        self.assertIn('SCULPTURE', ancient_node['children'])
    
    def test_cleanup_empty_nodes(self):
        """测试清理空节点"""
        self.tree.add_artifact(self.artifact1)
        self.assertEqual(len(self.tree.root.children), 1)  # Ancient节点
        
        # 移除文物
        self.tree.remove_artifact(1)
        self.assertEqual(len(self.tree.root.children), 0)  # 空节点被清理
    
    def test_artifact_sorting(self):
        """测试文物排序"""
        # 添加不同重要性的文物
        low_artifact = Artifact(
            artifact_id=5,
            name="Low Artifact",
            era="Modern",
            significance=Significance.LOW,
            artifact_type=ArtifactType.SCULPTURE
        )
        
        self.tree.add_artifact(low_artifact)  # LOW
        self.tree.add_artifact(self.artifact1)  # HIGH
        
        # 获取所有文物，应该按重要性排序（LOW在前，HIGH在后）
        all_artifacts = self.tree.get_all_artifacts()
        self.assertEqual(all_artifacts[0], low_artifact)    # LOW first
        self.assertEqual(all_artifacts[1], self.artifact1)  # HIGH second


class TestArtifactTreeNode(unittest.TestCase):
    """文物树节点的单元测试"""
    
    def setUp(self):
        """测试前的准备工作"""
        self.node = ArtifactTreeNode("test_node")
        self.artifact = Artifact(
            artifact_id=1,
            name="Test Artifact",
            era="Ancient",
            significance=Significance.HIGH,
            artifact_type=ArtifactType.SCULPTURE
        )
    
    def test_node_creation(self):
        """测试节点创建"""
        self.assertEqual(self.node.key, "test_node")
        self.assertEqual(len(self.node.artifacts), 0)
        self.assertEqual(len(self.node.children), 0)
    
    def test_add_artifact(self):
        """测试添加文物到节点"""
        self.node.add_artifact(self.artifact)
        self.assertEqual(len(self.node.artifacts), 1)
        self.assertEqual(self.node.artifacts[0], self.artifact)
    
    def test_remove_artifact(self):
        """测试从节点移除文物"""
        self.node.add_artifact(self.artifact)
        removed = self.node.remove_artifact(1)
        self.assertEqual(removed, self.artifact)
        self.assertEqual(len(self.node.artifacts), 0)
    
    def test_get_artifact(self):
        """测试获取节点中的文物"""
        self.node.add_artifact(self.artifact)
        found = self.node.get_artifact(1)
        self.assertEqual(found, self.artifact)
        
        not_found = self.node.get_artifact(999)
        self.assertIsNone(not_found)
    
    def test_node_repr(self):
        """测试节点的字符串表示"""
        self.node.add_artifact(self.artifact)
        expected = "ArtifactTreeNode(key='test_node', artifacts_count=1)"
        self.assertEqual(repr(self.node), expected)


if __name__ == '__main__':
    unittest.main()