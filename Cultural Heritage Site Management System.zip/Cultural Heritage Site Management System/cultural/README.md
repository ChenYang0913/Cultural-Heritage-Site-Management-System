# 文化遗产遗址管理系统----Cultural Heritage Site Management System(Bilingual report)

## 项目简介----Project Introduction

本项目是一个用于管理和保护文化遗产遗址的系统，重点实现高效组织文物、遗址内的结构，并管理游客参观。系统使用树结构对文物进行层次化组织，并使用队列结构管理游客参观流程。----
This project is a system for managing and protecting cultural heritage sites, focusing on efficiently organizing cultural relics, the structure within the site, and managing tourist visits. The system uses a tree structure to organize cultural relics in a hierarchical manner, and uses a queue structure to manage the visitor visit process.

## 功能特性----function characteristics

### 第一部分：文物组织----Part One: Cultural Relics Organizations

#### 🧱 任务一：定义数据结构----Task 1: Define Data Structures
- **文物树表示--Cultural Relic Tree Representation**：为遗址中的每一件文物设计Python类----Design Python classes for each cultural relic in the site
- **节点信息--node information**：包含文物编号、名称、所属时代、重要性、类型----Include cultural relic number, name, era, importance, and type
- **-枚举类型--Enumeration type**：定义重要性和类型的可能值----Define the possible values of importance and type
- **实用方法--practical method**：实现字符串表示、比较等操作----Implement string representation, comparison, and other operations

#### 🌳 树结构设计----Tree structure design
- 使用树结构表示文物的层级组织----Using tree structure to represent the hierarchical organization of cultural relics
- 按时代 → 类型 → 重要性分类----Classified by Era → Type → Importance
- 支持添加、删除、修改、搜索操作----Support adding, deleting, modifying, and searching operations

#### 🧪 完整测试----Complete testing
- 所有方法都使用unittest进行测试----All methods are tested using UnitTest

### 第二部分：游客体验管理----Tourist Experience Management

#### 🔁 队列结构表示----Queue structure representation
- **游客组管理--Tourist group management**：设计Python类管理游客导览队列----Design Python classes to manage tourist guide queues
- **节点信息--node information**：包含游客组编号、到达时间、预约优先级----Includes tourist group number, arrival time, and reservation priority
- **优先队列--Priority Queue**：根据到达时间与预约优先级决定顺序----Determine the order based on arrival time and reservation priority

#### 📊 队列工具函数----Queue tool function
- 添加游客组----Add tourist group
- 移除游客组----Remove tourist group
- 查看下一个游客组--View the next tourist group
- 重新安排导览时间--Reschedule the tour schedule

### 第三部分：高级功能----ADvanced

#### 🧩 基于游客偏好的导览优先安排----Priority arrangement of guided tours based on tourist preferences
- 支持游客选择感兴趣的历史时代----Supporting tourists to choose historical periods of interest
- 优化数据结构以支持游客偏好----Optimize data structure to support tourist preferences
- 确保高效安排游客导览----Ensure efficient arrangement of tourist guides

#### 🎨 图形用户界面----graphical user interface
- 现代化的GUI界面----Modern GUI interface
- 展示文物树和游客队列----Displaying cultural relics trees and tourist queues
- 支持添加、移除、查看详情等操作----Support operations such as adding, removing, and viewing details


### 第四部分：附加功能----Part Four: Additional Features

#### 💡 交互式遗址地图----Interactive Site Map
- 鼠标悬停显示文物详细信息----Hovering the mouse displays detailed information about cultural relics
- 点击删除节点功能----Click on the delete node function
- 右键菜单（查看详情、编辑、删除）----Right click menu (View Details, Edit, Delete)
- 双击编辑文物信息----Double click to edit cultural relic information
- 搜索高亮功能----Search Highlighting Function


#### 📈 文物保护分析----Analysis of Cultural Relic Protection
- 分析文物时代或类型分布----Analyze the distribution of cultural relics by age or type
- 识别需要扩展或加强保护的部分----Identify the parts that need to be expanded or strengthened for protection
- 数据可视化图表（饼图、柱状图）----Data visualization charts (pie chart, bar chart)
- 实时统计更新----Real time statistical updates

#### 🚶 游客流量优化----Optimization of tourist flow
- 分析游客在遗址中的流动情况----Analyze the flow of tourists in the site
- 识别可能的瓶颈----Identify potential bottlenecks
- 提供改进建议----Provide improvement suggestions
- 导览路线优化算法----Optimization algorithm for navigation route

#### 🎨 增强GUI功能----Enhance GUI functionality
- 现代化树形控件展示----Modern tree control display
- 实时搜索和高亮----Real time search and highlighting
- 数据导入导出功能----Data import and export function
- 图表可视化（需matplotlib）----Chart visualization (requires matplotlib)


## 项目结构

```
cultural/
├── core/                          # 
├── core/                       
│   ├── models/                    # 数据模型
│   │   ├── artifact.py           # 文物模型
│   │   └── visitors.py           # 游客模型
│   ├── structures/               # 数据结构
│   │   ├── artifact_tree.py      # 文物树
│   │   └── tour_queue.py         # 游客队列
│   ├── gui/                      # 图形界面
│   │   └── gui.py               # 主界面
│   └── manager.py               # 系统管理器
├── test/                         # 测试文件
│   ├── test_artifact.py         # 文物测试
│   ├── test_tree.py             # 树结构测试
│   ├── test_visitors.py         # 游客测试
│   ├── test_queue.py            # 队列测试
│   └── test_manager.py          # 管理器测试
├── file/                         # 数据文件
│   ├── cultural_heritage_artifacts.csv    # 文物数据
│   └── cultural_heritage_visitors.csv     # 游客数据
├── main.py                      # 主程序入口
├── run_tests.py                 # 测试运行器
└── README.md                    # 项目说明
```

## 安装和运行----Installation and operation

### 环境要求----Environmental requirements
- Python 3.7+  ----Python 3.7+
- tkinter (通常随Python安装)----Tkinter (usually installed with Python)
- matplotlib (可选，用于图表功能)----Matplotlib (optional, used for chart functionality)
- pandas (可选，用于数据处理)----Pandas (optional, used for data processing)

### 安装步骤

1. 克隆项目到本地----Clone project to local
```bash
git clone <repository-url>
cd cultural
```

2. 安装依赖（可选）----Install dependencies (optional)
```bash
pip install matplotlib pandas
```

3. 运行主程序----Run the main program
```bash
# 使用启动脚本（推荐）----Use startup script (recommended)
python run_gui.py

# 或直接运行----Or run directly
python main.py
```

3. 运行测试----Run test
```bash
# 运行所有测试----run all tests
python run_tests.py

# 运行特定测试----Run specific tests
python run_tests.py test_artifact
python run_tests.py test_tree
python run_tests.py test_visitors
python run_tests.py test_queue
python run_tests.py test_manager
```

## 使用说明----instructions

### 启动系统----Starting system
运行 `python main.py` 启动图形界面，系统会自动加载默认数据。
Run 'python main. py' to launch the graphical interface, and the system will automatically load default data.

### 文物管理----Cultural Relics Management
- **添加文物--Add cultural relics**：填写文物信息并点击"添加文物"----Fill in the cultural relic information and click "Add Cultural Relic"
- **搜索文物--Search for cultural relics**：选择类型和重要性进行搜索----Select type and importance for search
- **删除文物--Delete cultural relics**：输入文物ID进行删除----Enter the cultural relic ID to delete
- **查看树结构--View tree structure**：在文物管理选项卡中查看层次化结构----View hierarchical structure in the cultural relic management tab

### 游客管理----Visitor Management
- **添加游客组----Add tourist group**：填写游客组信息并点击"添加游客组"----
- **查看队列----View queue**：在游客管理选项卡中查看当前队列----View the current queue in the Visitor Management tab
- **队列操作----Queue operation**：查看下一个、移除下一个、重新安排时间----View next, remove next, reschedule time
- **删除游客组----Delete tourist group**：输入组ID进行删除----Enter the group ID to delete

### 系统统计----System Statistics
- 在统计选项卡中查看文物和游客的详细统计信息----View detailed statistical information of cultural relics and tourists in the statistics tab
- 包括时代分布、类型分布、重要性分布等----Including temporal distribution, type distribution, importance distribution, etc

### 高级功能----ADvanced
- **数据加载----Data Load**：从CSV文件加载文物和游客数据----Loading cultural relics and tourist data from CSV files
- **数据导出----data export**：导出过滤后的文物数据----Export filtered cultural relic data
- **游客偏好优化----Tourist preference optimization**：为游客组生成优化的导览路线----Generate optimized tour routes for tourist groups
- **数据可视化----Data visualization**：显示文物分布图表（需matplotlib）----Display the distribution chart of cultural relics (requires matplotlib)
- **实时搜索----Real Time Search**：在文物树中实时搜索和高亮匹配项----Real time search and highlight matching items in the cultural relic tree
- **右键菜单----Right click menu**：快速访问文物操作（查看、编辑、删除）----Quick access to cultural relics (view, edit, delete)

## 数据格式----data format

### 文物数据 (cultural_heritage_artifacts.csv)----Cultural Relics Data (cultural_ heritage _ artifacts. csv)
```csv
ID,名称,年代,重要性,类型
1,Statue of Zeus,Ancient,HIGH,SCULPTURE
2,Venus de Milo,Ancient,HIGH,SCULPTURE
3,Rosetta Stone,Ancient,HIGH,DOCUMENT
```

### 游客数据 (cultural_heritage_visitors.csv)----Tourist data (cultural_ heritage visitors. csv)
```csv
group_ID,arrival_time,reservation_priority
1,09:00,HIGH
2,09:30,MEDIUM
3,10:00,LOW
```

## 技术特点----FEATURES

### 数据结构----data structure
- **树结构----Tree structure**：用于层次化组织文物，支持快速搜索和分类----Used for hierarchical organization of cultural relics, supporting quick search and classification
- **优先队列----Priority Queue**：用于管理游客导览顺序，支持优先级和时间排序----Used to manage the order of tourist guides, supporting priority and time sorting
- **枚举类型----Enumeration type**：确保数据的一致性和类型安全----Ensure data consistency and type safety

### 设计模式----Design pattern
- **管理器模式----Manager Mode**：统一管理系统组件----Unified management system components
- **观察者模式----Observer mode**：GUI界面响应数据变化----GUI interface responds to data changes
- **策略模式----Strategic Mode**：支持不同的搜索和排序策略----Support different search and sorting strategies

### 测试覆盖----Test coverage
- 完整的单元测试覆盖----Complete unit testing coverage
- 测试所有核心功能----Test all core functions
- 支持自动化测试运行----Support automated testing and running

## 扩展功能----Extended functionality

### 自定义开发----Custom development
- 添加新的文物类型和重要性级别----Add new cultural relic types and importance levels
- 扩展游客偏好选项----Expand tourist preference options
- 自定义搜索和过滤条件----Customize search and filtering criteria
- 添加新的统计维度----Add a new statistical dimension
