import os
import csv
from pathlib import Path
from core.models.artifact import Artifact, Significance, ArtifactType
from typing import List, Optional, Dict, Any

class ArtifactTreeNode:
    """Artifact Tree Node Class"""
    
    def __init__(self, key: str, artifacts: List[Artifact] = None):
        """
        Initialize the tree node
        
        Args:
            key: Node key value (era, type, or importance)
            artifacts:A list of artifacts under this node
        """
        self.key = key
        self.artifacts = artifacts or []
        self.children: Dict[str, 'ArtifactTreeNode'] = {}
    
    def add_artifact(self, artifact: Artifact) -> None:
        """Add artifacts to the node"""
        self.artifacts.append(artifact)
        # Sort by importance
        self.artifacts.sort(reverse=True)
    
    def remove_artifact(self, artifact_id: int) -> Optional[Artifact]:
        """Removes artifacts from the node"""
        for i, artifact in enumerate(self.artifacts):
            if artifact.artifact_id == artifact_id:
                return self.artifacts.pop(i)
        return None
    
    def get_artifact(self, artifact_id: int) -> Optional[Artifact]:
        """Obtain artifacts with a specified ID"""
        for artifact in self.artifacts:
            if artifact.artifact_id == artifact_id:
                return artifact
        return None
    
    def __repr__(self) -> str:
        return f"ArtifactTreeNode(key='{self.key}', artifacts_count={len(self.artifacts)})"

class ArtifactTree:
    """Cultural relics tree is used to organize cultural relics in a hierarchical manner"""
    
    def __init__(self):
        """Initialize the artifact tree"""
        self.root = ArtifactTreeNode("root")
        self._artifact_count = 0
    
    def add_artifact(self, artifact: Artifact) -> bool:
        """
        Add artifacts to the tree
        
        Args:
            artifact: Artifacts to add
            
        Returns:
            bool: Whether the addition was successful
        """
        try:
            # Create or obtain an era node
            era_node = self.root.children.get(artifact.era)
            if era_node is None:
                era_node = ArtifactTreeNode(artifact.era)
                self.root.children[artifact.era] = era_node
            
            # Create or get a type node
            type_key = artifact.artifact_type.value
            type_node = era_node.children.get(type_key)
            if type_node is None:
                type_node = ArtifactTreeNode(type_key)
                era_node.children[type_key] = type_node
            
            # Create or get an importance node
            significance_key = artifact.significance.value
            significance_node = type_node.children.get(significance_key)
            if significance_node is None:
                significance_node = ArtifactTreeNode(significance_key)
                type_node.children[significance_key] = significance_node
            
            # Add artifacts to the final node
            significance_node.add_artifact(artifact)
            self._artifact_count += 1
            return True
            
        except Exception as e:
            print(f"An error occurred while adding an artifact: {e}")
            return False
    
    def remove_artifact(self, artifact_id: int) -> Optional[Artifact]:
        """
        Remove artifacts from trees
        
        Args:
            artifact_id: The ID of the artifact to be removed
            
        Returns:
            Optional[Artifact]: Removed artifacts will be returned if not found None
        """
        for era_node in self.root.children.values():
            for type_node in era_node.children.values():
                for significance_node in type_node.children.values():
                    removed_artifact = significance_node.remove_artifact(artifact_id)
                    if removed_artifact:
                        self._artifact_count -= 1
                        # Clean up empty nodes
                        self._cleanup_empty_nodes()
                        return removed_artifact
        return None
    
    def find_artifact(self, artifact_id: int) -> Optional[Artifact]:
        """
        Find artifacts with a specified ID
        
        Args:
            artifact_id: 文物ID
            
        Returns:
            Optional[Artifact]: Artifacts found, returned to None if not found
        """
        for era_node in self.root.children.values():
            for type_node in era_node.children.values():
                for significance_node in type_node.children.values():
                    artifact = significance_node.get_artifact(artifact_id)
                    if artifact:
                        return artifact
        return None
    
    def search_artifacts(self, artifact_type: Optional[ArtifactType] = None, 
                        significance: Optional[Significance] = None) -> List[Artifact]:
        """
        Search for artifacts of a specific type and importance
        
        Args:
            artifact_type: Artifact type filter
            significance: Importance filterImportance filter
            
        Returns:
            List[Artifact]: A list of eligible artifacts
        """
        results = []
        
        for era_node in self.root.children.values():
            for type_node in era_node.children.values():
                # Check the type filter
                if artifact_type and type_node.key != artifact_type.value:
                    continue
                    
                for significance_node in type_node.children.values():
                    # Check the importance filter
                    if significance and significance_node.key != significance.value:
                        continue
                    
                    results.extend(significance_node.artifacts)
        
        return results
    
    def get_artifacts_by_era(self, era: str) -> List[Artifact]:
        """
        Get all the artifacts from a specified era
        
        Args:
            era: 时代名称
            
        Returns:
            List[Artifact]: All artifacts of the era
        """
        results = []
        era_node = self.root.children.get(era)
        if era_node:
            for type_node in era_node.children.values():
                for significance_node in type_node.children.values():
                    results.extend(significance_node.artifacts)
        return results
    
    def get_all_artifacts(self) -> List[Artifact]:
        """
        Get all the artifacts
        
        Returns:
            List[Artifact]:  All artifacts of the era
        """
        results = []
        for era_node in self.root.children.values():
            for type_node in era_node.children.values():
                for significance_node in type_node.children.values():
                    results.extend(significance_node.artifacts)
        return results
    
    def get_tree_structure(self) -> Dict[str, Any]:
        """
        Get the complete structure of the tree
        
        Returns:
            Dict[str, Any]:A dictionary of the structure of the tree
        """
        def node_to_dict(node: ArtifactTreeNode) -> Dict[str, Any]:
            result = {
                'key': node.key,
                'artifacts': [artifact.to_dict() for artifact in node.artifacts],
                'children': {}
            }
            for child_key, child_node in node.children.items():
                result['children'][child_key] = node_to_dict(child_node)
            return result
        
        return node_to_dict(self.root)
    
    def _cleanup_empty_nodes(self) -> None:
        """Clean up empty nodes"""
                #Clean up the importance nodes
        for era_node in self.root.children.values():
            for type_node in list(era_node.children.values()):
                empty_significance_nodes = [
                    key for key, node in type_node.children.items() 
                    if not node.artifacts
                ]
                for key in empty_significance_nodes:
                    del type_node.children[key]
                
                # Clean up empty type nodes
                if not type_node.children:
                    era_node.children = {
                        k: v for k, v in era_node.children.items() 
                        if v != type_node
                    }
            
            # Clean up empty epoch nodes
            if not era_node.children:
                self.root.children = {
                    k: v for k, v in self.root.children.items() 
                    if v != era_node
                }
    
    def get_statistics(self) -> Dict[str, Any]:
        """
        Get artifact statistics
        
        Returns:
            Dict[str, Any]: Dictionary of statistics
        """
        stats = {
            'total_artifacts': self._artifact_count,
            'eras': {},
            'types': {},
            'significance': {}
        }
        
        for era_node in self.root.children.values():
            era_count = 0
            for type_node in era_node.children.values():
                type_count = 0
                for significance_node in type_node.children.values():
                    count = len(significance_node.artifacts)
                    era_count += count
                    type_count += count
                    
                    # Statistical importance
                    significance_key = significance_node.key
                    stats['significance'][significance_key] = stats['significance'].get(significance_key, 0) + count
                
                # The type of statistic
                type_key = type_node.key
                stats['types'][type_key] = stats['types'].get(type_key, 0) + type_count
            
            # The Statistical Era
            stats['eras'][era_node.key] = era_count
        
        return stats
    
    def __len__(self) -> int:
        """Returns the total number of artifacts"""
        return self._artifact_count
    
    def __repr__(self) -> str:
        return f"ArtifactTree(total_artifacts={self._artifact_count})"

def get_file_path(filename):
    base_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.normpath(os.path.join(base_dir, ".."))
    return os.path.join(project_root, "file", filename)

def load_artifacts_from_csv(file_path):
    artifacts = []
    if not os.path.exists(file_path):
        print(f"The file does not exist: {file_path}")
        return artifacts

    with open(file_path, mode='r', encoding='utf-8') as f:
        reader = csv.reader(f)
        for row in reader:
            if row[0].lower() == "artifact_id":  #Skip the header
                continue
            if len(row) != 5:
                print(f"Skip malformed lines: {row}")
                continue
            try:
                artifact = Artifact(
                    int(row[0]),
                    row[1],
                    row[2],
                    row[3].upper(),
                    row[4].upper()
                )
                artifacts.append(artifact)
            except Exception as e:
                print(f"Skip invalid lines: {row}, wrong：{e}")
    return artifacts

def export_artifacts_to_csv(artifacts, file_path):
    os.makedirs(os.path.dirname(file_path), exist_ok=True)
    
    with open(file_path, mode='w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(["artifact_id", "name", "era", "significance", "artifact_type"])
        for art in artifacts:
            writer.writerow([
                art.artifact_id,
                art.name,
                art.era,
                art.significance.name,
                art.artifact_type.name
            ])


