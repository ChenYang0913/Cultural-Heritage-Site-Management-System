from dataclasses import dataclass
from enum import Enum
from typing import Optional, List, Dict, Any
import csv
from datetime import datetime
import os  # Added for path processing
import heapq
from core.models.visitors import VisitorGroup, ReservationPriority

# Visitor group importance enumeration
class Significance(Enum):
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"

# Visitor group data class
@dataclass
class Group:
    group_id: str
    arrival_time: datetime
    reservation_priority: Significance

    def __repr__(self) -> str:
        return (f"Group(group_id={self.group_id}, "
                f"arrival_time={self.arrival_time.strftime('%Y-%m-%d %H:%M:%S')}, "
                f"reservation_priority={self.reservation_priority.name})")

    def __eq__(self, other) -> bool:
        if not isinstance(other, Group):
            return False
        return self.group_id == other.group_id

# Doubly linked list node class
class Node:
    def __init__(self, value: Group, prev: Optional['Node'] = None, next: Optional['Node'] = None):
        self.value = value
        self.prev = prev
        self.next = next

# Navigation queue class (doubly linked list implementation)
class TourQueue:
    """Visitor Guided Queue class, which uses priority queues to manage groups of visitors"""
    
    def __init__(self):
        """Initialize the tour queue"""
        self._queue: List[VisitorGroup] = []
        self._group_map: Dict[int, VisitorGroup] = {}  # For quick lookups
        self._next_id = 1
    
    def add_visitor_group(self, group: VisitorGroup) -> bool:
        """
        Add a group of visitors to the queue
        
        Args:
            group: The group of visitors to add
            
        Returns:
            bool: Whether the addition was successful
        """
        try:
            # Check if a group with the same ID already exists
            if group.group_id in self._group_map:
                return False
            
            # Add to the mapping table
            self._group_map[group.group_id] = group
            
            # Add to priority queue (max heap with negative priority)
            heapq.heappush(self._queue, group)
            return True
            
        except Exception as e:
            print(f"An error occurred while adding a guest group: {e}")
            return False
    
    def remove_visitor_group(self, group_id: int) -> Optional[VisitorGroup]:
        """
        Remove the guest group from the queue
        
        Args:
            group_id: The ID of the guest group to be removed
            
        Returns:
            Optional[VisitorGroup]: Groups of guests who have been removed will be returned to None if they are not found
        """
        if group_id not in self._group_map:
            return None
        
        # Removed from the mapping table
        group = self._group_map.pop(group_id)
        
        # Rebuild Queue (Remove Specified Group)
        self._queue = [g for g in self._queue if g.group_id != group_id]
        heapq.heapify(self._queue)
        
        return group
    
    def get_next_visitor_group(self) -> Optional[VisitorGroup]:
        """
        View the next group of guests (not removed)
        
        Returns:
            Optional[VisitorGroup]:The next group of visitors, if the queue is empty, returns None
        """
        if not self._queue:
            return None
        return self._queue[0]
    
    def dequeue_next_visitor_group(self) -> Optional[VisitorGroup]:
        """
        Remove and return to the next guest group
        
        Returns:
            Optional[VisitorGroup]: The next group of visitors, if the queue is empty, returns None
        """
        if not self._queue:
            return None
        
        group = heapq.heappop(self._queue)
        self._group_map.pop(group.group_id, None)
        return group
    
    def reschedule_visitor_group(self, group_id: int, new_arrival_time: str) -> bool:
        """
        Reschedule the tour for groups of visitors
        
        Args:
            group_id: 游客组ID
            new_arrival_time: 新的到达时间
            
        Returns:
            bool: Whether the rescheduling was successful
        """
        if group_id not in self._group_map:
            return False
        
        # Remove the original group
        old_group = self.remove_visitor_group(group_id)
        if not old_group:
            return False
        
        # Create a new group (leave other properties unchanged)
        new_group = VisitorGroup(
            group_id=old_group.group_id,
            count=old_group.count,
            arrival_time=new_arrival_time,
            reservation_priority=old_group.reservation_priority,
            preferred_era=old_group.preferred_era
        )
        
        # Add a new group
        return self.add_visitor_group(new_group)
    
    def update_visitor_group_priority(self, group_id: int, new_priority: ReservationPriority) -> bool:
        """
        Update the priority of the guest group
        
        Args:
            group_id: 游客组ID
            new_priority: 新的优先级
            
        Returns:
            bool: Whether the update was successful
        """
        if group_id not in self._group_map:
            return False
        
        # Remove the original group
        old_group = self.remove_visitor_group(group_id)
        if not old_group:
            return False
        
        # Create a new group (update priority)
        new_group = VisitorGroup(
            group_id=old_group.group_id,
            count=old_group.count,
            arrival_time=old_group.arrival_time,
            reservation_priority=new_priority,
            preferred_era=old_group.preferred_era
        )
        
        # Add a new group
        return self.add_visitor_group(new_group)
    
    def get_visitor_group(self, group_id: int) -> Optional[VisitorGroup]:
        """
        Obtain the group of visitors with the specified ID
        
        Args:
            group_id: 游客组ID
            
        Returns:
            Optional[VisitorGroup]: Groups of visitors found, returned to None if not found
        """
        return self._group_map.get(group_id)
    
    def get_all_visitor_groups(self) -> List[VisitorGroup]:
        """
        Get All Guest Groups (Prioritized)
        
        Returns:
            List[VisitorGroup]: A list of all visitor groups
        """
        return sorted(self._queue)
    
    def get_queue_position(self, group_id: int) -> Optional[int]:
        """
        Get the position of the guest group in the queue
        
        Args:
            group_id: 游客组ID
            
        Returns:
            Optional[int]:Queue location (from 1) and return None if not found
        """
        if group_id not in self._group_map:
            return None
        
        sorted_groups = sorted(self._queue)
        for i, group in enumerate(sorted_groups, 1):
            if group.group_id == group_id:
                return i
        return None
    
    def get_queue_statistics(self) -> Dict[str, Any]:
        """
        Get queue statistics
        
        Returns:
            Dict[str, Any]: Dictionary of statistics
        """
        stats = {
            'total_groups': len(self._queue),
            'significance_distribution': {
                'HIGH': 0,
                'MEDIUM': 0,
                'LOW': 0
            },
            'era_preferences': {}
        }
        for group in self._queue:
            priority = group.reservation_priority.value
            stats['significance_distribution'][priority] += 1
            if group.preferred_era:
                era = group.preferred_era
                stats['era_preferences'][era] = stats['era_preferences'].get(era, 0) + 1
        return stats
    
    def clear_queue(self) -> None:
        """Clear the queue"""
        self._queue.clear()
        self._group_map.clear()
    
    def is_empty(self) -> bool:
        """Check if the queue is empty"""
        return len(self._queue) == 0
    
    def __len__(self) -> int:
        """Returns the number of guest groups in the queue"""
        return len(self._queue)
    
    def __repr__(self) -> str:
        return f"TourQueue(total_groups={len(self._queue)})"
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert the queue to dictionary format"""
        return {
            'total_groups': len(self._queue),
            'groups': [group.to_dict() for group in sorted(self._queue)],
            'statistics': self.get_queue_statistics()
        }

# Load the data from a CSV file
def load_from_csv(file_name: str = "cultural_heritage_visitors.csv") -> TourQueue:  # Changed to the default file name parameter for more flexibility
    """Load the visitor group data from a CSV file and initialize the queue, which is read from the file folder by default"""
    # Gets the absolute path to the current file (tour_queue.py).
    current_file_path = os.path.abspath(__file__)
    # Get the directory where the current file is located (artifact_management folder)
    current_dir = os.path.dirname(current_file_path)
    # Get the root of the project (Cultural-main folder)
    project_root = os.path.dirname(current_dir)
    # Stitch together the relative path of the CSV file (assuming the CSV is placed in the file folder)
    csv_path = os.path.join(project_root, "file", file_name)
    
    queue = TourQueue()
    try:
        with open(csv_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                try:
                    group = Group(
                        group_id=row['group_id'],
                        arrival_time=datetime.strptime(row['arrival_time'], '%Y-%m-%d %H:%M:%S'),
                        reservation_priority=Significance[row['reservation_priority'].upper()]
                    )
                    queue.add_visitor_group(group)
                except (ValueError, KeyError) as e:
                    print(f"Invalid data rows, skipped：{row}，mistake：{e}")
    except FileNotFoundError:
        print(f"Error: CSV file not found {csv_path}")
    return queue