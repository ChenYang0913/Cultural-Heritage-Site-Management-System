import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from tkinter.scrolledtext import ScrolledText
import os
from typing import Optional, Dict, Any
from collections import Counter

# Try importing matplotlib and use the base version if it fails
try:
    import matplotlib.pyplot as plt
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
    import matplotlib
    matplotlib.use('TkAgg')
    # Set matplotlib to support Chinese
    matplotlib.rcParams['font.sans-serif'] = ['SimHei']  # 或 ['Microsoft YaHei']
    matplotlib.rcParams['axes.unicode_minus'] = False
    HAS_MATPLOTLIB = True
except ImportError:
    HAS_MATPLOTLIB = False

from core.manager import CulturalHeritageManager
from core.models.artifact import Artifact, Significance, ArtifactType
from core.models.visitors import VisitorGroup, ReservationPriority


class Tooltip:
    def __init__(self, widget):
        self.widget = widget
        self.tipwindow = None
    def show(self, text, x, y):
        self.hide()
        self.tipwindow = tw = tk.Toplevel(self.widget)
        tw.wm_overrideredirect(True)
        tw.wm_geometry(f"+{x+20}+{y+10}")
        label = tk.Label(tw, text=text, background="#ffffe0", relief=tk.SOLID, borderwidth=1, font=("Arial", 10))
        label.pack(ipadx=1)
    def hide(self):
        if self.tipwindow:
            self.tipwindow.destroy()
            self.tipwindow = None


class ArtifactEditDialog:
    def __init__(self, parent, artifact):
        self.dialog = tk.Toplevel(parent)
        self.dialog.title("Edit Artifact")
        self.dialog.geometry("400x300")
        self.dialog.transient(parent)
        self.dialog.grab_set()
        
        self.artifact = artifact
        self.result = None
        
        self.create_widgets()
        self.center_window()
    
    def create_widgets(self):
        # name
        ttk.Label(self.dialog, text="Name:").grid(row=0, column=0, sticky="w", padx=10, pady=5)
        self.name_var = tk.StringVar(value=self.artifact.name)
        ttk.Entry(self.dialog, textvariable=self.name_var, width=30).grid(row=0, column=1, padx=10, pady=5)
        
        # era
        ttk.Label(self.dialog, text="Era:").grid(row=1, column=0, sticky="w", padx=10, pady=5)
        self.era_var = tk.StringVar(value=self.artifact.era)
        ttk.Entry(self.dialog, textvariable=self.era_var, width=30).grid(row=1, column=1, padx=10, pady=5)
        
        # type
        ttk.Label(self.dialog, text="Type:").grid(row=2, column=0, sticky="w", padx=10, pady=5)
        self.type_var = tk.StringVar(value=self.artifact.artifact_type.value)
        type_combo = ttk.Combobox(self.dialog, textvariable=self.type_var, 
                                 values=[t.value for t in ArtifactType], state="readonly")
        type_combo.grid(row=2, column=1, padx=10, pady=5)
        
        # importance
        ttk.Label(self.dialog, text="Significance:").grid(row=3, column=0, sticky="w", padx=10, pady=5)
        self.significance_var = tk.StringVar(value=self.artifact.significance.value)
        sig_combo = ttk.Combobox(self.dialog, textvariable=self.significance_var,
                                values=[s.value for s in Significance], state="readonly")
        sig_combo.grid(row=3, column=1, padx=10, pady=5)
        
        # description
        ttk.Label(self.dialog, text="Description:").grid(row=4, column=0, sticky="w", padx=10, pady=5)
        self.description_var = tk.StringVar(value=self.artifact.description)
        ttk.Entry(self.dialog, textvariable=self.description_var, width=30).grid(row=4, column=1, padx=10, pady=5)
        
        # button
        button_frame = ttk.Frame(self.dialog)
        button_frame.grid(row=5, column=0, columnspan=2, pady=20)
        
        ttk.Button(button_frame, text="Save", command=self.save).pack(side=tk.LEFT, padx=10)
        ttk.Button(button_frame, text="Cancel", command=self.cancel).pack(side=tk.LEFT, padx=10)
    
    def center_window(self):
        self.dialog.update_idletasks()
        x = (self.dialog.winfo_screenwidth() // 2) - (400 // 2)
        y = (self.dialog.winfo_screenheight() // 2) - (300 // 2)
        self.dialog.geometry(f"400x300+{x}+{y}")
    
    def save(self):
        try:
            # Create a new artifact object
            new_artifact = Artifact(
                artifact_id=self.artifact.artifact_id,
                name=self.name_var.get(),
                era=self.era_var.get(),
                artifact_type=ArtifactType(self.type_var.get()),
                significance=Significance(self.significance_var.get()),
                description=self.description_var.get()
            )
            self.result = new_artifact
            self.dialog.destroy()
        except Exception as e:
            messagebox.showerror("Error", f"Save failed: {e}")
    
    def cancel(self):
        self.dialog.destroy()


class MainWindow:
    """The main window of the Cultural Heritage Site Management System"""
    
    def __init__(self, root):
        self.root = root
        self.root.title("Cultural Heritage Site Management System")
        self.root.geometry("1200x800")
        self.root.configure(bg='#f0f0f0')
        
        # Initialize the manager
        self.manager = CulturalHeritageManager()
        self.tooltip = Tooltip(self.root)
        self.highlighted_item = None
        
        # Create an interface
        self.create_widgets()
        self.load_default_data()
    
    def create_widgets(self):
        """Create an interface component"""
        #Create Main frame
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Create a title
        title_label = ttk.Label(main_frame, text="Cultural Heritage Site Management System", 
                               font=('Arial', 16, 'bold'))
        title_label.pack(pady=(0, 20))
        
        # Create tabs
        notebook = ttk.Notebook(main_frame)
        notebook.pack(fill=tk.BOTH, expand=True)
        
        # Artifact Management tab
        self.create_artifact_tab(notebook)
        
        # Visitor Management tab
        self.create_visitor_tab(notebook)
        
        # System Statistics tab
        self.create_statistics_tab(notebook)
        
        # Advanced Features tab
        self.create_advanced_tab(notebook)
    
    def create_artifact_tab(self, notebook):
        """Create an artifact management tab"""
        artifact_frame = ttk.Frame(notebook)
        notebook.add(artifact_frame, text="Artifact Management")
        
        # Left: Artifact tree display
        left_frame = ttk.Frame(artifact_frame)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))
        
        # Artifact tree title
        left_frame_label = ttk.Label(left_frame, text="Artifact Tree", font=('Arial', 12, 'bold'))
        left_frame_label.pack(pady=(0, 10))
        
        # The artifact tree visualization Canvas scrollbar
        canvas_frame = ttk.Frame(left_frame)
        canvas_frame.pack(fill=tk.BOTH, expand=False, pady=(0, 10))
        self.artifact_canvas = tk.Canvas(canvas_frame, width=400, height=350, bg="white", scrollregion=(0,0,2000,1000))
        h_scroll = tk.Scrollbar(canvas_frame, orient=tk.HORIZONTAL, command=self.artifact_canvas.xview)
        v_scroll = tk.Scrollbar(canvas_frame, orient=tk.VERTICAL, command=self.artifact_canvas.yview)
        self.artifact_canvas.configure(xscrollcommand=h_scroll.set, yscrollcommand=v_scroll.set)
        self.artifact_canvas.grid(row=0, column=0, sticky="nsew")
        h_scroll.grid(row=1, column=0, sticky="ew")
        v_scroll.grid(row=0, column=1, sticky="ns")
        canvas_frame.rowconfigure(0, weight=1)
        canvas_frame.columnconfigure(0, weight=1)
        self.artifact_canvas.bind("<Button-1>", self.on_artifact_canvas_click)
        self.artifact_canvas.bind("<Double-1>", self.on_artifact_canvas_double_click)
        self.artifact_canvas.bind("<Motion>", self.on_artifact_canvas_hover)
        self.artifact_canvas.bind("<Leave>", lambda e: self.tooltip.hide())
        
        # Search box
        search_frame = ttk.Frame(left_frame)
        search_frame.pack(fill=tk.X, pady=(0, 10))
        ttk.Label(search_frame, text="Search:").pack(side=tk.LEFT)
        self.search_var = tk.StringVar()
        self.search_entry = ttk.Entry(search_frame, textvariable=self.search_var)
        self.search_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(5, 0))
        self.search_var.trace('w', self.on_search_change)
        
        # Tree controls
        self.artifact_tree = ttk.Treeview(left_frame, columns=("info",), show="tree")
        self.artifact_tree.pack(fill=tk.BOTH, expand=True)
        
        # Binding events
        self.artifact_tree.bind("<Motion>", self.on_tree_hover)
        self.artifact_tree.bind("<Leave>", lambda e: self.tooltip.hide())
        self.artifact_tree.bind("<Double-1>", self.on_tree_double_click)
        self.artifact_tree.bind("<Button-3>", self.on_tree_right_click)
        
        # Context menu (Edit Artifact only)
        self.context_menu = tk.Menu(self.root, tearoff=0)
        self.context_menu.add_command(label="Edit Artifact", command=self.edit_artifact)
        
        # Right: Artifact operation
        right_frame = ttk.Frame(artifact_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.Y, padx=(10, 0))
        
        # Add an artifact area
        add_frame = ttk.LabelFrame(right_frame, text="Add Artifact", padding=10)
        add_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Artifact ID
        ttk.Label(add_frame, text="Artifact ID:").grid(row=0, column=0, sticky=tk.W, pady=2)
        self.artifact_id_var = tk.StringVar()
        ttk.Entry(add_frame, textvariable=self.artifact_id_var).grid(row=0, column=1, pady=2)
        
        # The name of the artifact
        ttk.Label(add_frame, text="Name:").grid(row=1, column=0, sticky=tk.W, pady=2)
        self.artifact_name_var = tk.StringVar()
        ttk.Entry(add_frame, textvariable=self.artifact_name_var).grid(row=1, column=1, pady=2)
        
        # era
        ttk.Label(add_frame, text="Era:").grid(row=2, column=0, sticky=tk.W, pady=2)
        self.artifact_era_var = tk.StringVar()
        era_combo = ttk.Combobox(add_frame, textvariable=self.artifact_era_var, 
                                values=["Ancient", "Medieval", "Renaissance", "Modern"], state="readonly")
        era_combo.grid(row=2, column=1, pady=2)
        
        # importance
        ttk.Label(add_frame, text="Significance:").grid(row=3, column=0, sticky=tk.W, pady=2)
        self.artifact_significance_var = tk.StringVar()
        significance_combo = ttk.Combobox(add_frame, textvariable=self.artifact_significance_var,
                                        values=["HIGH", "MEDIUM", "LOW"], state="readonly")
        significance_combo.grid(row=3, column=1, pady=2)
        
        # type
        ttk.Label(add_frame, text="Type:").grid(row=4, column=0, sticky=tk.W, pady=2)
        self.artifact_type_var = tk.StringVar()
        type_combo = ttk.Combobox(add_frame, textvariable=self.artifact_type_var,
                                 values=["SCULPTURE", "PAINTING", "DOCUMENT", "POTTERY", 
                                        "JEWELRY", "WEAPON", "TOOL", "TEXTILE"], state="readonly")
        type_combo.grid(row=4, column=1, pady=2)
        
        # Add a button
        ttk.Button(add_frame, text="Add Artifact", 
                  command=self.add_artifact).grid(row=5, column=0, columnspan=2, pady=10)
        
        # Search area
        search_frame = ttk.LabelFrame(right_frame, text="Search Artifact", padding=10)
        search_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Search type
        ttk.Label(search_frame, text="Type:").grid(row=0, column=0, sticky=tk.W, pady=2)
        self.search_type_var = tk.StringVar()
        search_type_combo = ttk.Combobox(search_frame, textvariable=self.search_type_var,
                                        values=["", "SCULPTURE", "PAINTING", "DOCUMENT", "POTTERY", 
                                               "JEWELRY", "WEAPON", "TOOL", "TEXTILE"], state="readonly")
        search_type_combo.grid(row=0, column=1, pady=2)
        
        # Search for importance
        ttk.Label(search_frame, text="Significance:").grid(row=1, column=0, sticky=tk.W, pady=2)
        self.search_significance_var = tk.StringVar()
        search_significance_combo = ttk.Combobox(search_frame, textvariable=self.search_significance_var,
                                               values=["", "HIGH", "MEDIUM", "LOW"], state="readonly")
        search_significance_combo.grid(row=1, column=1, pady=2)
        
        # Search button
        ttk.Button(search_frame, text="Search", 
                  command=self.search_artifacts).grid(row=2, column=0, columnspan=2, pady=10)
        
        # Delete the artifact area
        delete_frame = ttk.LabelFrame(right_frame, text="Delete Artifact", padding=10)
        delete_frame.pack(fill=tk.X)
        
        ttk.Label(delete_frame, text="Artifact ID:").grid(row=0, column=0, sticky=tk.W, pady=2)
        self.delete_artifact_id_var = tk.StringVar()
        ttk.Entry(delete_frame, textvariable=self.delete_artifact_id_var).grid(row=0, column=1, pady=2)
        
        ttk.Button(delete_frame, text="Delete Artifact", 
                  command=self.delete_artifact).grid(row=1, column=0, columnspan=2, pady=10)
    
    def create_visitor_tab(self, notebook):
        """Create a Visitor Management tab"""
        visitor_frame = ttk.Frame(notebook)
        notebook.add(visitor_frame, text="Visitor Management")
        
        left_frame = ttk.Frame(visitor_frame)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))
        
        # Visualization of the tree-like structure of the visitor queue
        left_frame_label = ttk.Label(left_frame, text="Visitor Queue Tree", font=('Arial', 12, 'bold'))
        left_frame_label.pack(pady=(0, 10))
        self.queue_canvas = tk.Canvas(left_frame, width=600, height=350, bg="white")
        self.queue_canvas.pack(fill=tk.BOTH, expand=False)
        self.queue_canvas.bind("<Motion>", self.on_visitor_canvas_hover)
        self.queue_canvas.bind("<Leave>", lambda e: self.visitor_info_label.config(text=""))
        self.queue_canvas.bind("<Button-1>", self.on_visitor_canvas_click)
        
        # Visitor queue text display
        queue_title = ttk.Label(left_frame, text="Visitor Queue (Priority Order):", font=('Arial', 10))
        queue_title.pack(pady=(10, 0))
        self.visitor_queue_text = ScrolledText(left_frame, height=15, width=50)
        self.visitor_queue_text.pack(fill=tk.BOTH, expand=True)
        
        # Right: Visitor operation
        right_frame = ttk.Frame(visitor_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.Y, padx=(10, 0))
        
        # Add a guest group area
        add_frame = ttk.LabelFrame(right_frame, text="Add Visitor Group", padding=10)
        add_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(add_frame, text="Group ID:").grid(row=0, column=0, sticky="w")
        self.visitor_id_var = tk.StringVar()
        self.visitor_id_entry = ttk.Entry(add_frame, textvariable=self.visitor_id_var)
        self.visitor_id_entry.grid(row=0, column=1, padx=(5, 0))
        self.visitor_id_entry.insert(0, "Please enter Group ID")
        self.visitor_id_entry.bind("<FocusIn>", lambda e: self.clear_placeholder(self.visitor_id_entry, "Please enter Group ID"))
        self.visitor_id_entry.bind("<FocusOut>", lambda e: self.set_placeholder(self.visitor_id_entry, "Please enter Group ID"))
        
        ttk.Label(add_frame, text="Count:").grid(row=1, column=0, sticky="w", pady=(5, 0))
        self.visitor_count_var = tk.StringVar()
        self.visitor_count_entry = ttk.Entry(add_frame, textvariable=self.visitor_count_var)
        self.visitor_count_entry.grid(row=1, column=1, padx=(5, 0), pady=(5, 0))
        self.visitor_count_entry.insert(0, "Please enter count")
        self.visitor_count_entry.bind("<FocusIn>", lambda e: self.clear_placeholder(self.visitor_count_entry, "Please enter count"))
        self.visitor_count_entry.bind("<FocusOut>", lambda e: self.set_placeholder(self.visitor_count_entry, "Please enter count"))
        
        ttk.Label(add_frame, text="Arrival Time:").grid(row=2, column=0, sticky="w", pady=(5, 0))
        self.arrival_time_var = tk.StringVar()
        self.arrival_time_entry = ttk.Entry(add_frame, textvariable=self.arrival_time_var)
        self.arrival_time_entry.grid(row=2, column=1, padx=(5, 0), pady=(5, 0))
        self.arrival_time_entry.insert(0, "Please enter arrival time")
        self.arrival_time_entry.bind("<FocusIn>", lambda e: self.clear_placeholder(self.arrival_time_entry, "Please enter arrival time"))
        self.arrival_time_entry.bind("<FocusOut>", lambda e: self.set_placeholder(self.arrival_time_entry, "Please enter arrival time"))
        
        ttk.Label(add_frame, text="Priority:").grid(row=3, column=0, sticky="w", pady=(5, 0))
        self.priority_var = tk.StringVar()
        self.priority_combo = ttk.Combobox(add_frame, textvariable=self.priority_var,
                                          values=[p.value for p in ReservationPriority], state="readonly")
        self.priority_combo.grid(row=3, column=1, padx=(5, 0), pady=(5, 0))
        
        ttk.Label(add_frame, text="Preferred Era:").grid(row=4, column=0, sticky="w", pady=(5, 0))
        self.era_preference_var = tk.StringVar()
        self.era_preference_entry = ttk.Entry(add_frame, textvariable=self.era_preference_var)
        self.era_preference_entry.grid(row=4, column=1, padx=(5, 0), pady=(5, 0))
        self.era_preference_entry.insert(0, "Please enter preferred era")
        self.era_preference_entry.bind("<FocusIn>", lambda e: self.clear_placeholder(self.era_preference_entry, "Please enter preferred era"))
        self.era_preference_entry.bind("<FocusOut>", lambda e: self.set_placeholder(self.era_preference_entry, "Please enter preferred era"))
        
        ttk.Button(add_frame, text="Add Visitor Group", command=self.add_visitor_group).grid(row=5, column=0, columnspan=2, pady=(10, 0))
        
        # Delete the Visitor Group area 
        delete_frame = ttk.LabelFrame(right_frame, text="Delete Visitor Group", padding=10)
        delete_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(delete_frame, text="Group ID:").grid(row=0, column=0, sticky="w")
        self.delete_visitor_id_var = tk.StringVar()
        self.delete_visitor_id_entry = ttk.Entry(delete_frame, textvariable=self.delete_visitor_id_var)
        self.delete_visitor_id_entry.grid(row=0, column=1, padx=(5, 0))
        self.delete_visitor_id_entry.insert(0, "Please enter the Group ID to delete")
        self.delete_visitor_id_entry.bind("<FocusIn>", lambda e: self.clear_placeholder(self.delete_visitor_id_entry, "Please enter the Group ID to delete"))
        self.delete_visitor_id_entry.bind("<FocusOut>", lambda e: self.set_placeholder(self.delete_visitor_id_entry, "Please enter the Group ID to delete"))
        
        ttk.Button(delete_frame, text="Delete Visitor Group", command=self.remove_visitor_group).grid(row=1, column=0, columnspan=2, pady=(10, 0))
    
    def create_statistics_tab(self, notebook):
        """Create a System Statistics tab"""
        stats_frame = ttk.Frame(notebook)
        notebook.add(stats_frame, text="Statistics")
        
        # Statistics are displayed
        self.stats_text = ScrolledText(stats_frame, height=35, width=80)
        self.stats_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Refresh button
        ttk.Button(stats_frame, text="Refresh Statistics", command=self.refresh_statistics).pack(pady=10)
    
    def create_advanced_tab(self, notebook):
        """Create an Advanced Features tab"""
        advanced_frame = ttk.Frame(notebook)
        notebook.add(advanced_frame, text="Advanced Features")
        
        if HAS_MATPLOTLIB:
            # Create a chart area
            chart_frame = ttk.LabelFrame(advanced_frame, text="Data Visualization", padding=10)
            chart_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
            
            # Create a matplotlib chart
            self.fig, (self.ax1, self.ax2) = plt.subplots(1, 2, figsize=(12, 5))
            self.canvas = FigureCanvasTkAgg(self.fig, chart_frame)
            self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
            
            #Update Chart button
            ttk.Button(chart_frame, text="Update Charts", command=self.update_charts).pack(pady=10)
        else:
            # Alternate display when matplotlib is not available
            info_frame = ttk.LabelFrame(advanced_frame, text="Data Visualization", padding=10)
            info_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
            
            info_text = ScrolledText(info_frame, height=15, width=60)
            info_text.pack(fill=tk.BOTH, expand=True)
            info_text.insert(tk.END, "Data visualization requires matplotlib support\n\n")
            info_text.insert(tk.END, "Please install the dependency package:\n")
            info_text.insert(tk.END, "pip install matplotlib pandas\n\n")
            info_text.insert(tk.END, "After installation, restart the program to use the chart feature")
            info_text.config(state=tk.DISABLED)
        
        # Advanced function buttons
        button_frame = ttk.Frame(advanced_frame)
        button_frame.pack(fill=tk.X, padx=10, pady=10)
        
        ttk.Button(button_frame, text="Optimize Tour Route", command=self.optimize_tour_route).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Export Data", command=self.export_data).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Import Data", command=self.import_data).pack(side=tk.LEFT, padx=5)
    
    def load_default_data(self):
        """Load the default data"""
        try:
            # Load artifact data
            artifact_file = os.path.join("file", "cultural_heritage_artifacts.csv")
            if os.path.exists(artifact_file):
                self.manager.load_artifact_data(artifact_file)
            
            # Load visitor data
            visitor_file = os.path.join("file", "cultural_heritage_visitors.csv")
            if os.path.exists(visitor_file):
                self.manager.load_visitor_data(visitor_file)
            
            # Update the display
            self.update_artifact_tree_display()
            self.update_visitor_queue_display()
            self.refresh_statistics()
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load default data: {e}")
    
    def refresh_displays(self):
        """Refresh all displays"""
        self.update_artifact_tree_display()
        self.update_visitor_queue_display()
        self.refresh_statistics()
    
    def update_artifact_tree_display(self):
        """Updating the artifact tree display (text tree and visualization tree)"""
        self.artifact_tree.delete(*self.artifact_tree.get_children())
        self.artifact_canvas.delete("all")
        if len(self.manager.artifact_tree) == 0:
            self.artifact_tree.insert("", "end", text="No artifact data")
            return
        structure = self.manager.get_tree_structure()
        def add_nodes(parent, node):
            for artifact in node['artifacts']:
                self.artifact_tree.insert(parent, "end", text=str(artifact['artifact_id']))
            for child_key, child_node in node['children'].items():
                child_id = self.artifact_tree.insert(parent, "end", text=child_key)
                add_nodes(child_id, child_node)
        add_nodes("", structure)
        self.artifact_tree.tag_configure("highlight", background="yellow")
        self.draw_artifact_tree_canvas(structure)

    def draw_artifact_tree_canvas(self, structure):
        """Recursively draw the artifact tree structure on Canvas (moderate node size, suitable for scrolling)"""
        canvas = self.artifact_canvas
        canvas.delete("all")
        node_radius = 24
        x0, y0 = 200, 40
        level_gap = 70
        positions = {}
        node_id_map = {}
        def count_leaves(node):
            if not node['children']:
                return max(1, len(node['artifacts']))
            return sum(count_leaves(child) for child in node['children'].values())
        def draw_node(node, x, y, level, parent_pos=None):
            leaves = count_leaves(node)
            width = leaves * node_radius * 2
            this_x = x
            # Sketchbook node
            label = node.get('key', 'Artifact') if level > 0 else 'Artifact'
            node_id = canvas.create_oval(this_x-node_radius, y-node_radius, this_x+node_radius, y+node_radius, fill="#ffe4b3", outline="#333", width=2)
            text_id = canvas.create_text(this_x, y, text=label, font=("Arial", 12, "bold"))
            node_id_map[node_id] = node
            positions[node_id] = (this_x, y)
            # Draw a line
            if parent_pos:
                canvas.create_line(parent_pos[0], parent_pos[1]+node_radius, this_x, y-node_radius, width=2)
            # Draw subnodes
            children = list(node['children'].items())
            if children:
                total_leaves = sum(count_leaves(child) for _, child in children)
                start_x = x - (total_leaves*node_radius*2)//2 + node_radius
                cur_x = start_x
                for key, child in children:
                    child_leaves = count_leaves(child)
                    child_x = cur_x + (child_leaves*node_radius)
                    draw_node(child, child_x, y+level_gap, level+1, (this_x, y))
                    cur_x += child_leaves*node_radius*2
            # Draw artifact leaf nodes
            for i, artifact in enumerate(node['artifacts']):
                ax = this_x - (len(node['artifacts'])-1)*node_radius + i*node_radius*2
                ay = y+level_gap
                leaf_id = canvas.create_oval(ax-node_radius//2, ay-node_radius//2, ax+node_radius//2, ay+node_radius//2, fill="#b3e0ff", outline="#333", width=2)
                text_id = canvas.create_text(ax, ay, text=f"A{artifact['artifact_id']}", font=("Arial", 10))
                node_id_map[leaf_id] = artifact
                positions[leaf_id] = (ax, ay)
                canvas.create_line(this_x, y+node_radius, ax, ay-node_radius//2, width=2)
        draw_node(structure, x0, y0, 0)
        self._artifact_canvas_node_map = node_id_map
        # Reset the scrollregion to fit the content
        canvas.config(scrollregion=canvas.bbox("all"))

    def on_artifact_canvas_click(self, event):
        """Clicking on the Canvas node does not pop up a window"""
        pass

    def on_artifact_canvas_hover(self, event):
        """English Tooltip overlay when hovering artifact tree node (only artifact leaf node displays)"""
        canvas = self.artifact_canvas
        found = False
        for node_id, data in getattr(self, '_artifact_canvas_node_map', {}).items():
            coords = canvas.coords(node_id)
            if coords and coords[0] <= event.x <= coords[2] and coords[1] <= event.y <= coords[3]:
                if isinstance(data, dict) and 'artifact_id' in data:
                    artifact = self.manager.find_artifact(data['artifact_id'])
                    if artifact:
                        text = f"Name: {artifact.name}\nEra: {artifact.era}\nType: {artifact.artifact_type.value}\nSignificance: {artifact.significance.value}"
                        self.tooltip.show(text, event.x_root, event.y_root)
                        found = True
                        break
        if not found:
            self.tooltip.hide()

    def update_visitor_queue_display(self):
        """English Tooltip overlay when hovering artifact tree node (only artifact leaf node displays)"""
        self.visitor_queue_text.delete(1.0, tk.END)
        visitor_groups = self.manager.tour_queue.get_all_visitor_groups()
        if len(visitor_groups) == 0:
            self.visitor_queue_text.insert(tk.END, "No visitor data\n")
        else:
            self.visitor_queue_text.insert(tk.END, "Visitor Queue (Priority Order):\n")
            self.visitor_queue_text.insert(tk.END, "=" * 50 + "\n\n")
            for i, group in enumerate(visitor_groups, 1):
                self.visitor_queue_text.insert(tk.END, f"{i}. Group ID: {group.group_id}\n")
                self.visitor_queue_text.insert(tk.END, f"    Count: {group.count}\n")
                self.visitor_queue_text.insert(tk.END, f"    Arrival Time: {group.arrival_time}\n")
                self.visitor_queue_text.insert(tk.END, f"    Priority: {group.reservation_priority.value}\n")
                if group.preferred_era:
                    self.visitor_queue_text.insert(tk.END, f"    Preferred Era: {group.preferred_era}\n")
                self.visitor_queue_text.insert(tk.END, "\n")
        self.draw_visitor_queue_tree(visitor_groups)

    def draw_visitor_queue_tree(self, visitor_groups):
        """Visualize queues beautifully in landscape queues on Canvas (rounded corners, centered, arrows beautified, hover highlight)"""
        canvas = self.queue_canvas
        canvas.delete("all")
        n = len(visitor_groups)
        if n == 0:
            return
        node_w, node_h = 100, 56
        gap = 36
        y0 = 80
        # Calculate the overall width and achieve centering
        total_width = n * node_w + (n-1) * gap
        x0 = max(20, (int(canvas['width']) - total_width)//2)
        # Gets the block you're currently hovering over
        hover_index = getattr(self, '_visitor_queue_hover_index', None)
        self._visitor_canvas_node_map = {}
        for i, group in enumerate(visitor_groups):
            x = x0 + i*(node_w+gap)
            y = y0
            # Determine whether to hover highlight
            outline_color = "#ff9900" if hover_index == i else "#333"
            outline_width = 3 if hover_index == i else 2
            # Draw a rounded rectangle
            self._draw_round_rect(canvas, x, y, x+node_w, y+node_h, r=16, fill="#b3e0ff", outline=outline_color, width=outline_width)
            # Content tiering is centered
            canvas.create_text(x+node_w//2, y+16, text=f"ID:{group.group_id}", font=("Arial", 12, "bold"))
            canvas.create_text(x+node_w//2, y+32, text=f"{group.reservation_priority.value}", font=("Arial", 11))
            canvas.create_text(x+node_w//2, y+46, text=f"{group.arrival_time}", font=("Arial", 10))
            self._visitor_canvas_node_map[(x, y, x+node_w, y+node_h)] = (i, group)
            # arrowhead
            if i > 0:
                ax1 = x-gap+8
                ax2 = x
                ay = y+node_h//2
                canvas.create_line(ax1, ay, ax2, ay, width=4, fill="#888", arrow=tk.LAST, arrowshape=(12,16,6))
        # Bind hover events
        canvas.bind("<Motion>", self._on_visitor_queue_hover)
        canvas.bind("<Leave>", self._on_visitor_queue_leave)

    def _draw_round_rect(self, canvas, x1, y1, x2, y2, r=12, fill="#b3e0ff", outline="#333", width=2):
        """Drawing a Rounded Rectangle on a Canvas (Parameter Security Correction)"""
        # Arcs at all corners
        arc_kwargs = {"style": tk.ARC, "outline": outline, "width": width}
        canvas.create_arc(x1, y1, x1+2*r, y1+2*r, start=90, extent=90, **arc_kwargs)
        canvas.create_arc(x2-2*r, y1, x2, y1+2*r, start=0, extent=90, **arc_kwargs)
        canvas.create_arc(x2-2*r, y2-2*r, x2, y2, start=270, extent=90, **arc_kwargs)
        canvas.create_arc(x1, y2-2*r, x1+2*r, y2, start=180, extent=90, **arc_kwargs)
        # Quadrilateral
        line_kwargs = {"fill": outline, "width": width}
        canvas.create_line(x1+r, y1, x2-r, y1, **line_kwargs)
        canvas.create_line(x2, y1+r, x2, y2-r, **line_kwargs)
        canvas.create_line(x2-r, y2, x1+r, y2, **line_kwargs)
        canvas.create_line(x1, y2-r, x1, y1+r, **line_kwargs)
        # padding
        canvas.create_rectangle(x1+r, y1, x2-r, y2, fill=fill, outline="")
        canvas.create_rectangle(x1, y1+r, x2, y2-r, fill=fill, outline="")

    def _on_visitor_queue_hover(self, event):
        """Queue flowchart hover highlight overlay information"""
        canvas = self.queue_canvas
        found = False
        for (x1, y1, x2, y2), (i, group) in self._visitor_canvas_node_map.items():
            if x1 <= event.x <= x2 and y1 <= event.y <= y2:
                self._visitor_queue_hover_index = i
                # Overlay information in English
                text = f"ID: {getattr(group, 'group_id', '')}\nCount: {getattr(group, 'count', '')}\nArrival Time: {getattr(group, 'arrival_time', '')}\nPriority: {getattr(group, 'reservation_priority', '')}"
                if getattr(group, 'preferred_era', None):
                    text += f"\nPreferred Era: {group.preferred_era}"
                self.tooltip.show(text, event.x_root, event.y_root)
                self.update_visitor_queue_display()
                found = True
                break
        if not found:
            self._visitor_queue_hover_index = None
            self.tooltip.hide()
            self.update_visitor_queue_display()

    def _on_visitor_queue_leave(self, event):
        self._visitor_queue_hover_index = None
        self.tooltip.hide()
        self.update_visitor_queue_display()

    def on_visitor_canvas_click(self, event):
        """Do nothing after clicking on the queue block (there is no information area below)"""
        pass

    def on_visitor_canvas_hover(self, event):
        """The information area below will no longer be updated, leaving it blank"""
        pass

    def refresh_statistics(self):
        """Refresh the statistics"""
        self.stats_text.delete(1.0, tk.END)
        stats = self.manager.get_system_statistics()
        self.stats_text.insert(tk.END, "System Statistics Information\n")
        self.stats_text.insert(tk.END, "=" * 50 + "\n\n")
        artifact_stats = stats['artifacts']
        self.stats_text.insert(tk.END, f"Total Artifacts: {artifact_stats['total_artifacts']}\n\n")
        self.stats_text.insert(tk.END, "By Era Distribution:\n")
        for era, count in artifact_stats['eras'].items():
            self.stats_text.insert(tk.END, f"  {era}: {count} items\n")
        self.stats_text.insert(tk.END, "\nBy Type Distribution:\n")
        for type_name, count in artifact_stats['types'].items():
            self.stats_text.insert(tk.END, f"  {type_name}: {count} items\n")
        self.stats_text.insert(tk.END, "\nBy Significance Distribution:\n")
        for significance, count in artifact_stats['significance'].items():
            self.stats_text.insert(tk.END, f"  {significance}: {count} items\n")
        visitor_stats = stats['visitors']
        self.stats_text.insert(tk.END, f"\nTotal Visitor Groups: {visitor_stats['total_groups']}\n\n")
        self.stats_text.insert(tk.END, "By Significance Distribution:\n")
        for priority, count in visitor_stats['significance_distribution'].items():
            self.stats_text.insert(tk.END, f"  {priority}: {count} groups\n")
        if visitor_stats['era_preferences']:
            self.stats_text.insert(tk.END, "\nEra Preference Distribution:\n")
            for era, count in visitor_stats['era_preferences'].items():
                self.stats_text.insert(tk.END, f"  {era}: {count} groups\n")
        # Recommendations for the protection of cultural relics
        self.stats_text.insert(tk.END, "\n[Artifact Protection Suggestion]\n")
        for era, count in artifact_stats['eras'].items():
            if count < 2:
                self.stats_text.insert(tk.END, f"  Few artifacts in {era} era, consider strengthening protection/expanding collection.\n")
        for type_name, count in artifact_stats['types'].items():
            if count < 2:
                self.stats_text.insert(tk.END, f"  Few artifacts of type {type_name}, consider strengthening protection/expanding collection.\n")
        # Visitor flow analysis
        arrival_times = [g.arrival_time for g in self.manager.tour_queue.get_all_visitor_groups()]
        time_counter = Counter(arrival_times)
        self.stats_text.insert(tk.END, "\n[Visitor Flow Analysis]\n")
        if time_counter:
            for t, c in time_counter.items():
                if c > 3:
                    self.stats_text.insert(tk.END, f"  High visitor flow at {t}, consider diversion or off-peak guidance.\n")
                else:
                    self.stats_text.insert(tk.END, f"  Normal visitor flow at {t}.\n")
        else:
            self.stats_text.insert(tk.END, "  No visitor flow data.\n")
    
    def add_artifact(self):
        """Add artifacts"""
        try:
            # Get the input values
            name = self.artifact_name_var.get()
            if not name:
                messagebox.showerror("Error", "Please enter artifact name")
                return
            
            era = self.artifact_era_var.get()
            if not era:
                messagebox.showerror("Error", "Please enter era")
                return
            
            artifact_type = ArtifactType(self.artifact_type_var.get())
            significance = Significance(self.artifact_significance_var.get())
            
            description = self.artifact_description_var.get() if hasattr(self, 'artifact_description_var') else ""
            
            # Create artifacts
            artifact = Artifact(
                artifact_id=len(self.manager.artifact_tree) + 1,
                name=name,
                era=era,
                artifact_type=artifact_type,
                significance=significance,
                description=description
            )
            
            # Add to the tree
            self.manager.add_artifact(artifact)
            
            # Update the display
            self.update_artifact_tree_display()
            self.refresh_statistics()
            
            # Clear the input box
            self.clear_artifact_inputs()
            
            messagebox.showinfo("Success", f"Artifact {name} has been added!")
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to add artifact: {e}")
    
    def clear_artifact_inputs(self):
        """Clear the artifact input box"""
        self.artifact_name_var.set("")
        self.artifact_era_var.set("")
        self.artifact_type_var.set("")
        self.artifact_significance_var.set("")
        if hasattr(self, 'artifact_description_var'):
            self.artifact_description_var.set("")
    
    def search_artifacts(self):
        """Search for artifacts"""
        try:
            artifact_type = None
            significance = None
            
            if self.search_type_var.get():
                artifact_type = ArtifactType[self.search_type_var.get()]
            if self.search_significance_var.get():
                significance = Significance[self.search_significance_var.get()]
            
            results = self.manager.search_artifacts(artifact_type, significance)
            
            if results:
                result_text = f"Found {len(results)} artifacts:\n\n"
                for artifact in results:
                    result_text += f"• {artifact.name} (ID: {artifact.artifact_id}, "
                    result_text += f"Era: {artifact.era}, Type: {artifact.artifact_type.value}, "
                    result_text += f"Significance: {artifact.significance.value})\n"
            else:
                result_text = "No artifacts found that meet the criteria"
            
            messagebox.showinfo("Search Results", result_text)
        except Exception as e:
            messagebox.showerror("Error", f"Search failed: {e}")

    def search_artifact(self):
        """Search for individual artifacts by ID"""
        try:
            artifact_id = self.delete_artifact_id_var.get()
            if not artifact_id:
                messagebox.showerror("Error", "Please enter artifact ID")
                return
            artifact_id = int(artifact_id)
            
            artifact = self.manager.find_artifact(artifact_id)
            if artifact:
                details = f"""Artifact Details:
Name: {artifact.name}
ID: {artifact.artifact_id}
Era: {artifact.era}
Type: {artifact.artifact_type.value}
Significance: {artifact.significance.value}
Description: {artifact.description}"""
                messagebox.showinfo("Search Results", details)
            else:
                messagebox.showinfo("Search Results", f"No artifact found with ID {artifact_id}")
                
        except ValueError as e:
            messagebox.showerror("Error", f"Input format error: {e}")
        except Exception as e:
            messagebox.showerror("Error", f"Search failed: {e}")
    
    def delete_artifact(self):
        """Delete artifacts"""
        try:
            artifact_id = self.delete_artifact_id_var.get()
            if not artifact_id or artifact_id == "Please enter artifact ID":
                messagebox.showerror("Error", "Please enter artifact ID")
                return
            artifact_id = int(artifact_id)
            removed = self.manager.remove_artifact(artifact_id)
            if removed:
                self.update_artifact_tree_display()
                self.refresh_statistics()
                messagebox.showinfo("Success", f"Artifact {artifact_id} has been deleted!")
                self.delete_artifact_id_var.set("")
            else:
                messagebox.showerror("Error", f"No artifact found with ID {artifact_id}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to delete artifact: {e}")
    
    def add_visitor_group(self):
        """Add a group of visitors"""
        try:
            # Get the input values
            group_id = self.visitor_id_var.get()
            if not group_id or group_id == "Please enter Group ID":
                messagebox.showerror("Error", "Please enter Group ID")
                return
            group_id = int(group_id)
            
            count = self.visitor_count_var.get()
            if not count or count == "Please enter count":
                messagebox.showerror("Error", "Please enter count")
                return
            count = int(count)
            
            arrival_time = self.arrival_time_var.get()
            if not arrival_time or arrival_time == "Please enter arrival time":
                messagebox.showerror("Error", "Please enter arrival time")
                return
            
            if not self.priority_var.get():
                messagebox.showerror("Error", "Please select priority")
                return
            priority = ReservationPriority(self.priority_var.get())
            
            preferred_era = self.era_preference_var.get()
            if preferred_era == "Please enter preferred era":
                preferred_era = ""
            
            # Create a group of visitors
            visitor_group = VisitorGroup(
                group_id=group_id,
                count=count,
                arrival_time=arrival_time,
                reservation_priority=priority,
                preferred_era=preferred_era
            )
            
            # Add to queue
            self.manager.add_visitor_group(visitor_group)
            
            # Update the display
            self.update_visitor_queue_display()
            self.refresh_statistics()
            
            # Clear the input box
            self.clear_visitor_inputs()
            
            messagebox.showinfo("Success", f"Visitor Group {group_id} has been added!")
            
        except ValueError as e:
            messagebox.showerror("Error", f"Input format error: {e}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to add visitor group: {e}")
    
    def remove_visitor_group(self):
        """Delete a guest group"""
        try:
            group_id = self.delete_visitor_id_var.get()
            if not group_id or group_id == "Please enter the Group ID to delete":
                messagebox.showerror("Error", "Please enter the Group ID to delete")
                return
            group_id = int(group_id)
            
            self.manager.remove_visitor_group(group_id)
            self.update_visitor_queue_display()
            self.refresh_statistics()
            
            # Clear the input box
            self.delete_visitor_id_var.set("")
            self.delete_visitor_id_entry.insert(0, "Please enter the Group ID to delete")
            
            messagebox.showinfo("Success", f"Visitor Group {group_id} has been deleted!")
            
        except ValueError as e:
            messagebox.showerror("Error", f"Input format error: {e}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to delete visitor group: {e}")
    
    def clear_visitor_inputs(self):
        """Clear the guest input box"""
        self.visitor_id_var.set("")
        self.visitor_id_entry.insert(0, "Please enter Group ID")
        self.visitor_count_var.set("")
        self.visitor_count_entry.insert(0, "Please enter count")
        self.arrival_time_var.set("")
        self.arrival_time_entry.insert(0, "Please enter arrival time")
        self.priority_var.set("")
        self.era_preference_var.set("")
        self.era_preference_entry.insert(0, "Please enter preferred era")
    
    def update_charts(self):
        """Update the chart"""
        if not HAS_MATPLOTLIB:
            messagebox.showinfo("Tip", "Chart feature requires matplotlib support, please install dependency package")
            return
            
        # Clear the previous chart
        self.ax1.clear()
        self.ax2.clear()
        
        # Get statistics
        stats = self.manager.get_system_statistics()
        artifact_stats = stats['artifacts']
        
        # Pie chart of the distribution of eras
        eras = list(artifact_stats['eras'].keys())
        era_counts = list(artifact_stats['eras'].values())
        self.ax1.pie(era_counts, labels=eras, autopct='%1.1f%%', startangle=90)
        self.ax1.set_title('Artifact Era Distribution')
        
        # Histogram of type distribution
        types = list(artifact_stats['types'].keys())
        type_counts = list(artifact_stats['types'].values())
        self.ax2.bar(types, type_counts, color='skyblue')
        self.ax2.set_title('Artifact Type Distribution')
        self.ax2.set_xlabel('Type')
        self.ax2.set_ylabel('Count')
        plt.setp(self.ax2.xaxis.get_majorticklabels(), rotation=45)
        
        # Adjust the layout
        self.fig.tight_layout()
        self.canvas.draw()
    
    def optimize_tour_route(self):
        """Optimize your guided routes"""
        try:
            # Get all guest groups
            visitor_groups = self.manager.tour_queue.get_all_visitor_groups()
            if not visitor_groups:
                messagebox.showinfo("Tip", "No visitor data")
                return
            
            # Simple optimization logic: sort by priority and arrival time
            optimized_groups = sorted(visitor_groups, 
                                    key=lambda x: (x.reservation_priority.value, x.arrival_time))
            
            # Displays the optimization results
            result = "Optimized Tour Route:\n"
            result += "=" * 30 + "\n\n"
            
            for i, group in enumerate(optimized_groups, 1):
                result += f"{i}. Group ID: {group.group_id}\n"
                result += f"    Priority: {group.reservation_priority.value}\n"
                result += f"    Arrival Time: {group.arrival_time}\n"
                if group.preferred_era:
                    result += f"    Recommended Visit: {group.preferred_era} Era Artifact\n"
                result += "\n"
            
            messagebox.showinfo("Tour Route Optimization", result)
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to optimize tour route: {e}")
    
    def clear_placeholder(self, entry, placeholder):
        """Clear the placeholders"""
        if entry.get() == placeholder:
            entry.delete(0, tk.END)
    
    def set_placeholder(self, entry, placeholder):
        """Set a placeholder"""
        if not entry.get():
            entry.insert(0, placeholder)

    def view_artifact_details(self):
        """View artifact details"""
        selection = self.artifact_tree.selection()
        if not selection:
            return
        
        item = selection[0]
        artifact_id = self.artifact_tree.item(item, "text")
        if not artifact_id.isdigit():
            return
        
        artifact = self.manager.find_artifact(int(artifact_id))
        if artifact:
            details = f"""Artifact Details:
Name: {artifact.name}
ID: {artifact.artifact_id}
Era: {artifact.era}
Type: {artifact.artifact_type.value}
Significance: {artifact.significance.value}
Description: {artifact.description}"""
            messagebox.showinfo("Artifact Details", details)

    def edit_artifact(self):
        """Edit artifacts"""
        selection = self.artifact_tree.selection()
        if not selection:
            return
        
        item = selection[0]
        artifact_id = self.artifact_tree.item(item, "text")
        if not artifact_id.isdigit():
            return
        
        artifact = self.manager.find_artifact(int(artifact_id))
        if artifact:
            dialog = ArtifactEditDialog(self.root, artifact)
            self.root.wait_window(dialog.dialog)
            
            if dialog.result:
                # Update artifacts
                self.manager.remove_artifact(artifact.artifact_id)
                self.manager.add_artifact(dialog.result)
                self.update_artifact_tree_display()
                self.refresh_statistics()
                messagebox.showinfo("Success", "Artifact has been updated!")

    def on_tree_hover(self, event):
        """Mouse-over events"""
        item = self.artifact_tree.identify_row(event.y)
        if item:
            artifact_id = self.artifact_tree.item(item, "text")
            if artifact_id.isdigit():
                artifact = self.manager.find_artifact(int(artifact_id))
                if artifact:
                    text = f"Name: {artifact.name}\nEra: {artifact.era}\nType: {artifact.artifact_type.value}\nSignificance: {artifact.significance.value}"
                    self.tooltip.show(text, event.x_root, event.y_root)
        else:
            self.tooltip.hide()

    def on_tree_click(self, event):
        item = self.artifact_tree.identify_row(event.y)
        if item:
            artifact_id = self.artifact_tree.item(item, "text")
            artifact = self.manager.find_artifact(int(artifact_id))
            if artifact and messagebox.askyesno("Confirm", f"Are you sure you want to delete artifact {artifact.name} (ID:{artifact_id})?"):
                self.manager.remove_artifact(int(artifact_id))
                self.update_artifact_tree_display()
                self.refresh_statistics()
                messagebox.showinfo("Success", f"Artifact {artifact.name} has been deleted!")

    def on_search_change(self, *args):
        """Highlight matches when the content of the search box changes"""
        search_text = self.search_var.get().lower()
        if not search_text:
            self.clear_highlights()
            return
        
        # Clear the previous highlight
        self.clear_highlights()
        
        # Highlight the matching item
        for item in self.artifact_tree.get_children():
            self.highlight_matching_items(item, search_text)
    
    def highlight_matching_items(self, item, search_text):
        """Recursively highlight the matching item"""
        item_text = self.artifact_tree.item(item, "text")
        if search_text in item_text.lower():
            self.artifact_tree.item(item, tags=("highlight",))
        
        for child in self.artifact_tree.get_children(item):
            self.highlight_matching_items(child, search_text)
    
    def clear_highlights(self):
        """Clear all highlights"""
        for item in self.artifact_tree.get_children():
            self.clear_item_highlights(item)
    
    def clear_item_highlights(self, item):
        """Highlight recursively purge items"""
        self.artifact_tree.item(item, tags=())
        for child in self.artifact_tree.get_children(item):
            self.clear_item_highlights(child)

    def on_tree_right_click(self, event):
        """Right-click events: Only artifact leaf nodes can be edited"""
        item = self.artifact_tree.identify_row(event.y)
        if item:
            artifact_id = self.artifact_tree.item(item, "text")
            if artifact_id.isdigit():
                self.artifact_tree.selection_set(item)
                self.context_menu.post(event.x_root, event.y_root)

    def on_tree_double_click(self, event):
        """Double-click event: Only artifact leaf nodes pop up the edit dialog"""
        item = self.artifact_tree.identify_row(event.y)
        if item:
            artifact_id = self.artifact_tree.item(item, "text")
            if artifact_id.isdigit():
                self.artifact_tree.selection_set(item)
                self.edit_artifact()

    def on_artifact_canvas_double_click(self, event):
        """Double-click the Canvas artifact leaf node to bring up an edit dialog"""
        canvas = self.artifact_canvas
        node_map = getattr(self, '_artifact_canvas_node_map', {})
        for node_id, data in node_map.items():
            coords = canvas.coords(node_id)
            if coords and coords[0] <= event.x <= coords[2] and coords[1] <= event.y <= coords[3]:
                if isinstance(data, dict) and 'artifact_id' in data:
                    artifact = self.manager.find_artifact(data['artifact_id'])
                    if artifact:
                        dialog = ArtifactEditDialog(self.root, artifact)
                        self.root.wait_window(dialog.dialog)
                        if dialog.result:
                            self.manager.remove_artifact(artifact.artifact_id)
                            self.manager.add_artifact(dialog.result)
                            self.update_artifact_tree_display()
                            self.refresh_statistics()
                            messagebox.showinfo("Success", "Artifact has been updated!")
                        break

    def export_data(self):
        """Export data"""
        filename = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
        )
        if filename:
            try:
                self.manager.export_data(filename)
                messagebox.showinfo("Success", f"Data exported to {filename}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to export data: {e}")

    def import_data(self):
        """Import data"""
        filename = filedialog.askopenfilename(
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")]
        )
        if filename:
            try:
                self.manager.load_data(filename)
                self.update_artifact_tree_display()
                self.update_visitor_queue_display()
                self.refresh_statistics()
                messagebox.showinfo("Success", f"Data imported from {filename}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to import data: {e}")


if __name__ == "__main__":
    root = tk.Tk()
    app = MainWindow(root)
    root.mainloop()