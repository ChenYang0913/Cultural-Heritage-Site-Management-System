import csv
import os
from typing import List, Optional, Dict, Any
from core.models.artifact import Artifact, Significance, ArtifactType
from core.models.visitors import VisitorGroup, ReservationPriority
from core.structures.artifact_tree import ArtifactTree
from core.structures.tour_queue import TourQueue


class CulturalHeritageManager:
    """文化遗产遗址管理系统管理器"""
    
    def __init__(self):
        """初始化管理器"""
        self.artifact_tree = ArtifactTree()
        self.tour_queue = TourQueue()
        self._loaded_artifacts = False
        self._loaded_visitors = False
    
    def load_artifacts_from_csv(self, file_path: str) -> bool:
        """
        从CSV文件加载文物数据
        
        Args:
            file_path: CSV文件路径
            
        Returns:
            bool: 是否成功加载
        """
        try:
            if not os.path.exists(file_path):
                print(f"文件不存在: {file_path}")
                return False
            
            with open(file_path, 'r', encoding='utf-8-sig') as file:
                reader = csv.DictReader(file)
                
                for row in reader:
                    try:
                        # 解析数据
                        artifact_id = int(row['ID'])
                        name = row['名称'].strip()
                        era = row['年代'].strip()
                        significance = Significance[row['重要性'].strip()]
                        artifact_type = ArtifactType[row['类型'].strip()]
                        
                        # 创建文物对象
                        artifact = Artifact(
                            artifact_id=artifact_id,
                            name=name,
                            era=era,
                            significance=significance,
                            artifact_type=artifact_type
                        )
                        
                        # 添加到树中
                        if not self.artifact_tree.add_artifact(artifact):
                            print(f"添加文物失败: {artifact}")
                            
                    except (ValueError, KeyError) as e:
                        print(f"解析文物数据时出错: {row}, 错误: {e}")
                        continue
            
            self._loaded_artifacts = True
            print(f"成功加载 {len(self.artifact_tree)} 件文物")
            return True
            
        except Exception as e:
            print(f"加载文物数据时出错: {e}")
            return False
    
    def load_visitors_from_csv(self, filepath):
        """
        从CSV文件加载游客数据
        
        Args:
            filepath: CSV文件路径
            
        Returns:
            bool: 是否成功加载
        """
        try:
            if not os.path.exists(filepath):
                print(f"文件不存在: {filepath}")
                return False
            
            with open(filepath, encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    # 兼容没有count字段的情况，默认1
                    count = int(row.get('count', 1))
                    group_id = int(row.get('group_ID') or row.get('group_id'))
                    arrival_time = row['arrival_time']
                    reservation_priority = ReservationPriority(row['reservation_priority'])
                    preferred_era = row.get('preferred_era')
                    group = VisitorGroup(
                        group_id=group_id,
                        count=count,
                        arrival_time=arrival_time,
                        reservation_priority=reservation_priority,
                        preferred_era=preferred_era
                    )
                    self.add_visitor_group(group)
            self._loaded_visitors = True
            print(f"成功加载 {len(self.tour_queue)} 个游客组")
            return True
            
        except Exception as e:
            print(f"加载游客数据时出错: {e}")
            return False
    
    def add_artifact(self, artifact: Artifact) -> bool:
        """
        添加文物
        
        Args:
            artifact: 文物对象
            
        Returns:
            bool: 是否成功添加
        """
        return self.artifact_tree.add_artifact(artifact)
    
    def remove_artifact(self, artifact_id: int) -> Optional[Artifact]:
        """
        移除文物
        
        Args:
            artifact_id: 文物ID
            
        Returns:
            Optional[Artifact]: 被移除的文物
        """
        return self.artifact_tree.remove_artifact(artifact_id)
    
    def find_artifact(self, artifact_id: int) -> Optional[Artifact]:
        """
        查找文物
        
        Args:
            artifact_id: 文物ID
            
        Returns:
            Optional[Artifact]: 找到的文物
        """
        return self.artifact_tree.find_artifact(artifact_id)
    
    def search_artifacts(self, artifact_type: Optional[ArtifactType] = None,
                        significance: Optional[Significance] = None) -> List[Artifact]:
        """
        搜索文物
        
        Args:
            artifact_type: 文物类型过滤器
            significance: 重要性过滤器
            
        Returns:
            List[Artifact]: 符合条件的文物列表
        """
        return self.artifact_tree.search_artifacts(artifact_type, significance)
    
    def add_visitor_group(self, group: VisitorGroup) -> bool:
        """
        添加游客组
        
        Args:
            group: 游客组对象
            
        Returns:
            bool: 是否成功添加
        """
        return self.tour_queue.add_visitor_group(group)
    
    def remove_visitor_group(self, group_id: int) -> Optional[VisitorGroup]:
        """
        移除游客组
        
        Args:
            group_id: 游客组ID
            
        Returns:
            Optional[VisitorGroup]: 被移除的游客组
        """
        return self.tour_queue.remove_visitor_group(group_id)
    
    def get_next_visitor_group(self) -> Optional[VisitorGroup]:
        """
        获取下一个游客组（不移除）
        
        Returns:
            Optional[VisitorGroup]: 下一个游客组
        """
        return self.tour_queue.get_next_visitor_group()
    
    def dequeue_next_visitor_group(self) -> Optional[VisitorGroup]:
        """
        移除并返回下一个游客组
        
        Returns:
            Optional[VisitorGroup]: 下一个游客组
        """
        return self.tour_queue.dequeue_next_visitor_group()
    
    def reschedule_visitor_group(self, group_id: int, new_arrival_time: str) -> bool:
        """
        重新安排游客组时间
        
        Args:
            group_id: 游客组ID
            new_arrival_time: 新的到达时间
            
        Returns:
            bool: 是否成功重新安排
        """
        return self.tour_queue.reschedule_visitor_group(group_id, new_arrival_time)
    
    def get_artifacts_by_era(self, era: str) -> List[Artifact]:
        """
        获取指定时代的所有文物
        
        Args:
            era: 时代名称
            
        Returns:
            List[Artifact]: 该时代的所有文物
        """
        return self.artifact_tree.get_artifacts_by_era(era)
    
    def get_artifacts_for_visitor_preference(self, preferred_era: str) -> List[Artifact]:
        """
        根据游客偏好获取文物（高级功能）
        
        Args:
            preferred_era: 偏好的时代
            
        Returns:
            List[Artifact]: 符合偏好的文物列表
        """
        return self.artifact_tree.get_artifacts_by_era(preferred_era)
    
    def optimize_tour_for_visitor_group(self, group_id: int) -> Optional[List[Artifact]]:
        """
        为游客组优化导览路线（高级功能）
        
        Args:
            group_id: 游客组ID
            
        Returns:
            Optional[List[Artifact]]: 优化的导览路线
        """
        group = self.tour_queue.get_visitor_group(group_id)
        if not group or not group.preferred_era:
            return None
        
        # 获取偏好时代的文物
        preferred_artifacts = self.get_artifacts_for_visitor_preference(group.preferred_era)
        
        # 按重要性排序
        preferred_artifacts.sort(reverse=True)
        
        return preferred_artifacts
    
    def get_system_statistics(self) -> Dict[str, Any]:
        """
        获取系统统计信息
        
        Returns:
            Dict[str, Any]: 系统统计信息
        """
        return {
            'artifacts': self.artifact_tree.get_statistics(),
            'visitors': self.tour_queue.get_queue_statistics(),
            'data_loaded': {
                'artifacts': self._loaded_artifacts,
                'visitors': self._loaded_visitors
            }
        }
    
    def export_filtered_artifacts(self, output_file: str, 
                                 artifact_type: Optional[ArtifactType] = None,
                                 significance: Optional[Significance] = None) -> bool:
        """
        导出过滤后的文物数据
        
        Args:
            output_file: 输出文件路径
            artifact_type: 文物类型过滤器
            significance: 重要性过滤器
            
        Returns:
            bool: 是否成功导出
        """
        try:
            artifacts = self.search_artifacts(artifact_type, significance)
            
            with open(output_file, 'w', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                writer.writerow(['ID', '名称', '年代', '重要性', '类型'])
                
                for artifact in artifacts:
                    writer.writerow([
                        artifact.artifact_id,
                        artifact.name,
                        artifact.era,
                        artifact.significance.value,
                        artifact.artifact_type.value
                    ])
            
            print(f"成功导出 {len(artifacts)} 件文物到 {output_file}")
            return True
            
        except Exception as e:
            print(f"导出文物数据时出错: {e}")
            return False
    
    def get_tree_structure(self) -> Dict[str, Any]:
        """
        获取文物树结构
        
        Returns:
            Dict[str, Any]: 树结构字典
        """
        return self.artifact_tree.get_tree_structure()
    
    def get_queue_structure(self) -> Dict[str, Any]:
        """
        获取游客队列结构
        
        Returns:
            Dict[str, Any]: 队列结构字典
        """
        return self.tour_queue.to_dict()
    
    def clear_all_data(self) -> None:
        """清空所有数据"""
        self.artifact_tree = ArtifactTree()
        self.tour_queue = TourQueue()
        self._loaded_artifacts = False
        self._loaded_visitors = False
    
    def __repr__(self) -> str:
        return (f"CulturalHeritageManager(artifacts={len(self.artifact_tree)}, "
                f"visitors={len(self.tour_queue)})")

    def load_artifact_data(self, filepath):
        """兼容接口：加载文物数据（推荐用于GUI和演示脚本）"""
        return self.load_artifacts_from_csv(filepath)

    def load_visitor_data(self, filepath):
        """兼容接口：加载游客数据（推荐用于GUI和演示脚本）"""
        return self.load_visitors_from_csv(filepath)